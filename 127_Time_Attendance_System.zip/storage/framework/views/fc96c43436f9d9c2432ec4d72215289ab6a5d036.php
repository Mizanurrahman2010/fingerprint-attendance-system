<?php $__env->startSection('content'); ?>
<!-- begin #content -->
<div id="content" class="content  attendance_settings">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li><a href="javascript:;">Home</a></li>
        <li class="active">Attendance Rule Create</li>
    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header">Attendance Rule <small> Create Attendance Rule</small></h1>
    <!-- end page-header -->

    <!-- begin row -->
    <div class="row">
        <!-- begin col-8 -->
        <div class="col-md-6">
            <!-- start: registration -->
            <div class="panel panel-inverse">
                <div class="panel-heading">
                    <div class="panel-heading-btn">
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-repeat"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger" data-click="panel-remove"><i class="fa fa-times"></i></a>
                    </div>
                    <h4 class="panel-title">Attendance Rule Create</h4>
                </div>
                <div class="panel-body">
                    <form action="#" method="POST" name="" class="form-horizontal form_registration">
                        <div id="">

                            <!-- begin wizard step-1 -->
                            <div class="step-1">

                            </div>
                            <fieldset>
                                <legend class="pull-left width-full">Attendance Rule Create</legend>
                                <!-- begin row -->
                                <div class="row">
                                    <?php echo e(csrf_field()); ?>


                                    <div class="form-group">
                                        <label for="name" class="col-md-4 control-label"> Rule Name</label>
                                        <div class="col-md-6">
                                            <input id="name" type="text" class="form-control" name="name" value="" required autofocus>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="current_status" class="col-md-4 control-label">Entry Time</label>
                                        <div class="col-md-6">
                                            <div class="btn-group" role="group" aria-label="...">
                                                <select class="btn btn-primary" name="entry_time_hour">
                                                    <option value="-1">Hour</option>
                                                    <option>1</option>
                                                    <option>2</option>
                                                    <option>3</option>
                                                    <option>4</option>
                                                    <option>5</option>
                                                    <option>6</option>
                                                    <option>7</option>
                                                    <option>8</option>
                                                    <option>9</option>
                                                    <option>10</option>
                                                    <option>11</option>
                                                    <option>12</option>
                                                </select>
                                                <select class="btn btn-primary" name="entry_time_minute">
                                                    <option value="-1">Minute</option>
                                                    <option value="00">00</option>
                                                    <option value="01">01</option>
                                                    <option value="02">02</option>
                                                    <option value="03">03</option>
                                                    <option value="04">04</option>
                                                    <option value="05">05</option>
                                                    <option value="06">06</option>
                                                    <option value="07">07</option>
                                                    <option value="08">08</option>
                                                    <option value="09">09</option>
                                                    <option value="10">10</option>

                                                    <option value="11">11</option>
                                                    <option value="12">12</option>
                                                    <option value="13">13</option>
                                                    <option value="14">14</option>
                                                    <option value="15">15</option>
                                                    <option value="16">16</option>
                                                    <option value="17">17</option>
                                                    <option value="18">18</option>
                                                    <option value="19">19</option>
                                                    <option value="20">20</option>

                                                    <option value="21">21</option>
                                                    <option value="22">22</option>
                                                    <option value="23">23</option>
                                                    <option value="24">24</option>
                                                    <option value="25">25</option>
                                                    <option value="26">26</option>
                                                    <option value="27">27</option>
                                                    <option value="28">28</option>
                                                    <option value="29">29</option>
                                                    <option value="30">30</option>

                                                    <option value="31">31</option>
                                                    <option value="32">32</option>
                                                    <option value="33">33</option>
                                                    <option value="34">34</option>
                                                    <option value="35">35</option>
                                                    <option value="36">36</option>
                                                    <option value="37">37</option>
                                                    <option value="38">38</option>
                                                    <option value="39">39</option>
                                                    <option value="40">40</option>

                                                    <option value="41">41</option>
                                                    <option value="42">42</option>
                                                    <option value="43">43</option>
                                                    <option value="44">44</option>
                                                    <option value="45">45</option>
                                                    <option value="46">46</option>
                                                    <option value="47">47</option>
                                                    <option value="48">48</option>
                                                    <option value="49">49</option>
                                                    <option value="50">50</option>

                                                    <option value="51">51</option>
                                                    <option value="52">52</option>
                                                    <option value="53">53</option>
                                                    <option value="54">54</option>
                                                    <option value="55">55</option>
                                                    <option value="56">56</option>
                                                    <option value="57">57</option>
                                                    <option value="58">58</option>
                                                    <option value="59">59</option>
                                                </select>
                                                <select class="btn btn-primary" name="entry_time_am_pm">
                                                    <option value="am">AM</option>
                                                    <option value="pm">PM</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="current_status" class="col-md-4 control-label">Out Time</label>
                                        <div class="col-md-6">
                                            <div class="btn-group" role="group" aria-label="...">
                                                <select class="btn btn-primary" name="out_time_hour">
                                                    <option value="-1">Hour</option>
                                                    <option value="1">1</option>
                                                    <option value="2">2</option>
                                                    <option value="3">3</option>
                                                    <option value="4">4</option>
                                                    <option value="5">5</option>
                                                    <option value="6">6</option>
                                                    <option value="7">7</option>
                                                    <option value="8">8</option>
                                                    <option value="9">9</option>
                                                    <option value="10">10</option>
                                                    <option value="11">11</option>
                                                    <option value="12">12</option>
                                                </select>
                                                <select class="btn btn-primary" name="out_time_minute">
                                                    <option value="-1">Minute</option>
                                                    <option value="00">00</option>
                                                    <option value="01">01</option>
                                                    <option value="02">02</option>
                                                    <option value="03">03</option>
                                                    <option value="04">04</option>
                                                    <option value="05">05</option>
                                                    <option value="06">06</option>
                                                    <option value="07">07</option>
                                                    <option value="08">08</option>
                                                    <option value="09">09</option>
                                                    <option value="10">10</option>

                                                    <option value="11">11</option>
                                                    <option value="12">12</option>
                                                    <option value="13">13</option>
                                                    <option value="14">14</option>
                                                    <option value="15">15</option>
                                                    <option value="16">16</option>
                                                    <option value="17">17</option>
                                                    <option value="18">18</option>
                                                    <option value="19">19</option>
                                                    <option value="20">20</option>

                                                    <option value="21">21</option>
                                                    <option value="22">22</option>
                                                    <option value="23">23</option>
                                                    <option value="24">24</option>
                                                    <option value="25">25</option>
                                                    <option value="26">26</option>
                                                    <option value="27">27</option>
                                                    <option value="28">28</option>
                                                    <option value="29">29</option>
                                                    <option value="30">30</option>

                                                    <option value="31">31</option>
                                                    <option value="32">32</option>
                                                    <option value="33">33</option>
                                                    <option value="34">34</option>
                                                    <option value="35">35</option>
                                                    <option value="36">36</option>
                                                    <option value="37">37</option>
                                                    <option value="38">38</option>
                                                    <option value="39">39</option>
                                                    <option value="40">40</option>

                                                    <option value="41">41</option>
                                                    <option value="42">42</option>
                                                    <option value="43">43</option>
                                                    <option value="44">44</option>
                                                    <option value="45">45</option>
                                                    <option value="46">46</option>
                                                    <option value="47">47</option>
                                                    <option value="48">48</option>
                                                    <option value="49">49</option>
                                                    <option value="50">50</option>

                                                    <option value="51">51</option>
                                                    <option value="52">52</option>
                                                    <option value="53">53</option>
                                                    <option value="54">54</option>
                                                    <option value="55">55</option>
                                                    <option value="56">56</option>
                                                    <option value="57">57</option>
                                                    <option value="58">58</option>
                                                    <option value="59">59</option>
                                                </select>
                                                <select class="btn btn-primary" name="out_time_am_pm">
                                                    <option value="am">AM</option>
                                                    <option value="pm">PM</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="current_status" class="col-md-4 control-label">Validate From</label>
                                        <div class="col-md-6">
                                            <div class="input-group date" id="datetimepicker1">
                                                <input type="text" class="form-control" name="validate_from" placeholder="27-10-2017" />
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="username" class="col-md-4 control-label">Validate To</label>
                                        <div class="col-md-6">
                                            <div class="input-group date" id="datetimepicker2">
                                                <input type="text" class="form-control" name="validate_to" placeholder="27-10-2017" />
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="current_status" class="col-md-4 control-label">Department</label>
                                        <div class="col-md-6">
                                            <select class="form-control" name="department" required autofocus>
                                                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($department->id); ?>"><?php echo e($department->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="username" class="col-md-4 control-label">Attendance Special Group</label>
                                        <div class="col-md-6">
                                           <select class="form-control" name="attendance_special_group" required autofocus>
                                                <option value="0">Default</option>
                                                <option value="1">Group 1</option>
                                                <option value="2">Group 2</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="username" class="col-md-4 control-label">Priority</label>
                                        <div class="col-md-6">
                                            <input id="username" type="text" class="form-control" name="priority" placeholder="1" value="" required autofocus>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label for="status" class="col-md-4 control-label">Status</label>
                                        <div class="col-md-6">
                                            <select class="form-control" name="status" required autofocus>
                                                <option value="0">Enable</option>
                                                <option value="1">Disable</option>
                                            </select>
                                        </div>
                                    </div>

                                </div>
                                <!-- end row -->
                            </fieldset>
                            <button type="button" class="btn btn-primary center-block btn_create">Create Attendance Rule <span class="glyphicon glyphicon-arrow-down" aria-hidden="true"></span></button>
                            <!-- end wizard step-1 -->
                            <!-- #modal-alert -->
                            <div class="modal fade" id="modal-alert">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <h4 class="modal-title">Student Creation</h4>
                                        </div>
                                        <div class="modal-body">
                                            <div class="alert alert-success m-b-0">
                                                <h4><i class="fa fa-info-circle"></i> Successfully Student Created</h4>
                                                <p>To update / delete/ / view student info click the link below the registration page</p>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <a href="javascript:;" class="btn btn-sm btn-success" data-dismiss="modal">Done</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <!-- end: registration -->
        </div>
    </div>
    <!-- end row -->
</div>
<!-- end #content -->
<!-- start : staff registration -->
<script>
    $(document).ready(function() {

        /*
         * Start : Student Registration
         * */

        $(".attendance_settings").on('click','.btn_create',function()
        {
            var _token                      = $("input[name=_token]").val();
            var name                        = $(".attendance_settings input[name=name]").val();

            var entry_time_hour             = $(".attendance_settings select[name=entry_time_hour]").val();
            var entry_time_minute           = $(".attendance_settings select[name=entry_time_minute]").val();
            var entry_time_am_pm            = $(".attendance_settings select[name=entry_time_am_pm]").val();

            var out_time_hour               = $(".attendance_settings select[name=out_time_hour]").val();
            var out_time_minute             = $(".attendance_settings select[name=out_time_minute]").val();
            var out_time_am_pm              = $(".attendance_settings select[name=out_time_am_pm]").val();

            var validate_from               = $(".attendance_settings input[name=validate_from]").val();
            var validate_to                 = $(".attendance_settings input[name=validate_to]").val();
            var department                  = $(".attendance_settings select[name=department]").val();
            var attendance_special_group    = $(".attendance_settings select[name=attendance_special_group]").val();
            var priority                    = $(".attendance_settings input[name=priority]").val();
            var status                      = $(".attendance_settings select[name=status]").val();

            var AttendanceRuleInfo = {

                _token                      : _token ,
                name                        : name ,      

                entry_time_hour             : entry_time_hour,
                entry_time_minute           : entry_time_minute,
                entry_time_am_pm            : entry_time_am_pm,

                out_time_hour               : out_time_hour,
                out_time_minute             : out_time_minute,
                out_time_am_pm              : out_time_am_pm,

                validate_from               : validate_from ,
                validate_to                 : validate_to ,
                department                  : department ,
                attendance_special_group    : attendance_special_group ,
                priority                    : priority ,
                status                      : status 
            };

            request.method   = "POST"       	              ;
            request.route    = 'admin/attendance/rule/create' ;
            request.action   = ''          	                  ;
            request.data     = AttendanceRuleInfo             ;
            request.sync     = true		                      ;

            var response = ajaxapp.request('$("#modal-alert").modal("show");','');
            //setTimeout(function(){ FPS_StatusGetCon = true; FPS_Status() },1000);
        });
        /*
         * end : Student Registration
         *
         * Retrive period - 15 seconds
         * */
    });
</script>
<!-- end : staff registration -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>