<?php $__env->startSection('content'); ?>
<!-- begin #content -->
<div id="content" class="content staff_update">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li><a href="javascript:;">Home</a></li>
        <li><a href="javascript:;">Extra</a></li>
        <li class="active">Profile Page</li>
    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header">Profile Page <small>header small text goes here...</small></h1>
    <!-- end page-header -->
    <!-- begin profile-container -->
    <div class="profile-container">
        <!-- begin profile-section -->
        <div class="profile-section">
            <!-- begin profile-left -->
            <div class="profile-left">
                <!-- begin profile-image -->
                <div class="profile-image">
                    <img src="<?php echo e(asset('img/profile-cover.jpg')); ?>" />
                    <i class="fa fa-user hide"></i>
                </div>
                <!-- end profile-image -->
                <div class="m-b-10">
                    <a href="#" class="btn btn-warning btn-block btn-sm">Change Picture</a>
                </div>
                <!-- begin profile-highlight -->
                <div class="profile-highlight">
                    <h4><i class="fa fa-cog"></i> Only My Contacts</h4>
                    <div class="checkbox m-b-5 m-t-0">
                        <label><input type="checkbox" /> Show my timezone</label>
                    </div>
                    <div class="checkbox m-b-0">
                        <label><input type="checkbox" /> Show i have 14 contacts</label>
                    </div>
                </div>
                <!-- end profile-highlight -->
            </div>
            <!-- end profile-left -->
            <!-- begin profile-right -->
            <div class="profile-right">
                <!-- begin profile-info -->
                <div class="profile-info">
                    <!-- begin table -->
                    <div class="table-responsive">
                        <table class="table table-profile">
                            <thead>
                            <tr>
                                <th></th>
                                <th>
                                    <?php echo e(csrf_field()); ?>

                                    <h4 data-id="<?php echo e($staff->id); ?>"> <?php echo e($staff->name); ?> <small><?php echo e($staff->designation); ?></small></h4>
                                </th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr class="highlight">
                                <td class="field">Mood</td>
                                <td><a href="#">Add Mood Message</a></td>
                            </tr>
                            <tr class="divider">
                                <td colspan="2"></td>
                            </tr>
                            <tr>
                                <td class="field">Mobile</td>
                                <td><i class="fa fa-mobile fa-lg m-r-5"></i> <?php echo e($staff->mobile_number); ?> <a href="#" class="m-l-5">Edit</a></td>
                            </tr>
                            <tr>
                                <td class="field">Email</td>
                                <td><a href="#"><?php echo e($staff->email); ?></a></td>
                            </tr>
                            <tr class="divider">
                                <td colspan="2"></td>
                            </tr>
                            <tr class="highlight">
                                <td class="field">About Me</td>
                                <td><a href="#">Add Description</a></td>
                            </tr>
                            <tr class="divider">
                                <td colspan="2"></td>
                            </tr>
                            <tr>
                                <td class="field">Country/Region</td>
                                <td>
                                    <select class="form-control input-inline" name="region">
                                        <option value="US" selected>United State</option>
                                        <option value="AF">Afghanistan</option>
                                        <option value="AL">Albania</option>
                                        <option value="DZ">Algeria</option>
                                        <option value="AS">American Samoa</option>
                                        <option value="AD">Andorra</option>
                                        <option value="AO">Angola</option>
                                        <option value="AI">Anguilla</option>
                                        <option value="AQ">Antarctica</option>
                                        <option value="AG">Antigua and Barbuda</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td class="field">City</td>
                                <td>Los Angeles</td>
                            </tr>
                            <tr>
                                <td class="field">State</td>
                                <td><a href="#">Add State</a></td>
                            </tr>
                            <tr>
                                <td class="field">Website</td>
                                <td><a href="#">Add Webpage</a></td>
                            </tr>
                            <tr>
                                <td class="field">Gender</td>
                                <td>
                                    <select class="form-control input-inline" name="gender">
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td class="field">Birthdate</td>
                                <td>
                                    <select class="form-control input-inline" name="day">
                                        <option value="04" selected>04</option>
                                    </select>
                                    -
                                    <select class="form-control input-inline" name="month">
                                        <option value="11" selected>11</option>
                                    </select>
                                    -
                                    <select class="form-control input-inline" name="year">
                                        <option value="1989" selected>1989</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td class="field">Language</td>
                                <td>
                                    <select class="form-control input-inline" name="language">
                                        <option value="" selected>English</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td class="field">Designation</td>
                                <td>
                                    <select class="form-control input-inline" name="designation" required autofocus>
                                        <option value="1">Assistant Engineer</option>
                                        <option value="2">Account Office</option>
                                        <option value="2">Sub. Assistant Engineer</option>
                                        <option value="2">Assistant Engineer</option>
                                        <option value="2">Assistant Engineer</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td class="field">Current Status</td>
                                <td>
                                    <select class="form-control input-inline" name="current_status" required="" autofocus="">
                                        <option value="1">Active</option>
                                        <option value="2">Leave</option>
                                        <option value="2">Suspand</option>
                                        <option value="2">Temporary Leave</option>
                                        <option value="2">Temporary Suspand</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td class="field">Username</td>
                                <td>
                                    <input class="form-control input-inline" type="text" name="username">
                                </td>
                            </tr>
                            <tr>
                                <td class="field">Password</td>
                                <td>
                                    <input class="form-control input-inline" type="password" name="password">
                                </td>
                            </tr>
                            <tr>
                                <td class="field">Current Address</td>
                                <td>
                                    <input class="form-control input-inline" type="text" name="current_address">
                                </td>
                            </tr>
                            <tr>
                                <td class="field">Permanent Address</td>
                                <td>
                                    <input class="form-control input-inline" type="text" name="permanent_address">
                                </td>
                            </tr>
                            <tr>
                                <td class="field">FPS ID</td>
                                <td>
                                    <input class="form-control input-inline" type="text" name="fps_id">
                                    <button type="button" class="btn btn-primary m-r-5 m-b-5 update">Update By FPS Direct Scan</button>
                                </td>
                            </tr>
                            <tr>
                                <td class="field">Status</td>
                                <td>
                                    <select class="form-control input-inline" name="status" required="" autofocus="">
                                        <option value="0">Enable</option>
                                        <option value="1">Disable</option>
                                    </select>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <button type="button" class="btn btn-primary center-block">Update <i class="fa fa-upload"></i></button>
                    </div>
                    <!-- end table -->
                </div>
                <!-- end profile-info -->
            </div>
            <!-- end profile-right -->
        </div>
        <!-- end profile-section -->
        <!-- begin profile-section -->
        <div class="profile-section">
            <!-- begin row -->
            <!-- end row -->
        </div>
        <!-- end profile-section -->
    </div>
    <!-- end profile-container -->
</div>
<!-- end #content -->
<!-- start : student registration -->
<script>
    $(document).ready(function() {
        /*
         * Start : FPS Update By Direct Scan
         * */

        $(".staff_update").on('click','.update',function()
        {
            var _token                  = $("input[name=_token]").val();
            var id                      = $(".staff_update [data-id]").attr("data-id");
            var username                = $(".staff_update input[name=username]").val();
            var mobile_number           = $(".staff_update input[name=mobile_number]").val();
            var email                   = $(".staff_update input[name=email]").val();

            var StaffInfo = {

                _token  : _token,
                id      : id
            };

            request.method   = "POST"                         ;
            request.route    = 'admin/staffs/profile/'+id+'/update/fpsdirectscan'  ;
            request.action   = ''                             ;
            request.data     = StaffInfo                    ;
            request.sync     = true                           ;

            var response = ajaxapp.request(
                    'FPS_StatusGetCon = false;' +
                    'FPS_StatusSetClear = true;' +
                    '$(".ViewProfile").attr("href",HTTP_SERVER+"/admin/student/profile/"+return_data+"/view");' +
                    '$(".SuccessInfo").show();' +
                    '$("#modal-alert").modal("show");','');
            //setTimeout(function(){ FPS_StatusGetCon = true; FPS_Status() },1000);
        });
        /*
         * end : FPS Update By Direct Scan
         *
         * Retrive period - 15 seconds
         * */
    });
</script>
<!-- end : student registration -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>