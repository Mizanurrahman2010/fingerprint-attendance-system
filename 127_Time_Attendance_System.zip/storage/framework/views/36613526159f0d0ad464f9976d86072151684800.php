<?php $__env->startSection('content'); ?>
<!-- begin #content -->
<div id="content" class="content staff_update">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li><a href="javascript:;">Home</a></li>
        <li class="active">Dashboard</li>
    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header">Staff Profile <small> Staff information</small></h1>
    <!-- end page-header -->

    <!-- begin row -->
    <div class="row">
        <!-- begin col-8 -->
        <div class="col-md-6">
            <!-- start: staff view -->
            <div class="panel panel-inverse">
                <div class="panel-heading">
                    <div class="panel-heading-btn">
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-repeat"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger" data-click="panel-remove"><i class="fa fa-times"></i></a>
                    </div>
                    <h4 class="panel-title">Office Staff</h4>
                </div>
                <div class="panel-body" style="position: relative;">
                    <div class="overlay"></div>
                    <form action="#" method="POST" name="" class="form-horizontal">

                        <!-- begin wizard step-1 -->
                        <legend class="pull-left width-full">Office Staff</legend>
                        <!-- begin row -->
                        <div class="row">
                            <?php echo e(csrf_field()); ?>


                            <div class="form-group">
                                <label for="name" class="col-md-4 control-label">Name</label>
                                <div class="col-md-6">
                                    <input id="name" type="text" class="form-control" name="name" value="<?php echo e($staff->name); ?>" required autofocus>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="designation" class="col-md-4 control-label">Department</label>
                                <div class="col-md-6">
                                    <select class="form-control" name="department" required autofocus>
                                        <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($department->id); ?>" <?php echo e(($staff->department_id == $department->id) ? 'selected=selected':''); ?> > <?php echo e($department->name); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="designation" class="col-md-4 control-label">Designation</label>
                                <div class="col-md-6">
                                    <select class="form-control" name="designation" required autofocus>
                                        <?php $__currentLoopData = $staff_designations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($designation->id); ?>" <?php echo e(($staff->designation_id == $designation->id) ? 'selected=selected':''); ?> > <?php echo e($designation->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="joining_date" class="col-md-4 control-label">Joining Date</label>
                                <div class="col-md-6">
                                    <select aria-label="Day" name="joining_date_day" title="Day" class="form-control input-inline">
                                        <option value="0">Day</option>
                                        <?php for($i = 1; $i <= 31; $i++): ?>
                                            <option value="<?php echo e($i); ?>" <?php echo e(($staff->joining_date_day == $i) ? 'selected=selected':''); ?> ><?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                    <select aria-label="Month" name="joining_date_month" title="Month" class="form-control input-inline">
                                        <option value="0">Month</option>
                                        <option value="1" <?php echo e(($staff->joining_date_month == 1) ? 'selected=selected':''); ?> >Jan</option>
                                        <option value="2" <?php echo e(($staff->joining_date_month == 2) ? 'selected=selected':''); ?> >Feb</option>
                                        <option value="3" <?php echo e(($staff->joining_date_month == 3) ? 'selected=selected':''); ?> >Mar</option>
                                        <option value="4" <?php echo e(($staff->joining_date_month == 4) ? 'selected=selected':''); ?> >Apr</option>
                                        <option value="5" <?php echo e(($staff->joining_date_month == 5) ? 'selected=selected':''); ?> >May</option>
                                        <option value="6" <?php echo e(($staff->joining_date_month == 6) ? 'selected=selected':''); ?> >Jun</option>
                                        <option value="7" <?php echo e(($staff->joining_date_month == 7) ? 'selected=selected':''); ?> >Jul</option>
                                        <option value="8" <?php echo e(($staff->joining_date_month == 8) ? 'selected=selected':''); ?> >Aug</option>
                                        <option value="9" <?php echo e(($staff->joining_date_month == 9) ? 'selected=selected':''); ?> >Sept</option>
                                        <option value="10" <?php echo e(($staff->joining_date_month == 10) ? 'selected=selected':''); ?> >Oct</option>
                                        <option value="11" <?php echo e(($staff->joining_date_month == 11) ? 'selected=selected':''); ?> >Nov</option>
                                        <option value="12" <?php echo e(($staff->joining_date_month == 12) ? 'selected=selected':''); ?> >Dec</option>
                                    </select>
                                    <select aria-label="Year" name="joining_date_year" title="Year" class="form-control input-inline">
                                        <option value="0">Year</option>
                                        <?php for($i = 2017; $i >= 1905; $i--): ?>
                                            <option value="<?php echo e($i); ?>" <?php echo e(($staff->joining_date_year == $i) ? 'selected=selected':''); ?> ><?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="current_status" class="col-md-4 control-label">Current Status</label>
                                <div class="col-md-6">
                                    <select class="form-control" name="current_status" required autofocus>
                                        <?php $__currentLoopData = $staff_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($status->id); ?>" <?php echo e(($staff->staff_status_id == $status->id) ? 'selected=selected':''); ?> > <?php echo e($status->name); ?> </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="username" class="col-md-4 control-label">Username</label>
                                <div class="col-md-6">
                                    <input id="username" type="text" class="form-control" name="username" value="<?php echo e($staff->username); ?>" required autofocus>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="password" class="col-md-4 control-label">Password</label>
                                <div class="col-md-6">
                                    <input id="password" type="password" class="form-control" name="password" value="" required autofocus>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="mobile_number" class="col-md-4 control-label">Mobile Number</label>
                                <div class="col-md-6">
                                    <input id="mobile_number" type="text" class="form-control" name="mobile_number" value="<?php echo e($staff->mobile_number); ?>" required autofocus>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="email" class="col-md-4 control-label">E-Mail Address</label>
                                <div class="col-md-6">
                                    <input id="email" type="email" class="form-control" name="email" value="<?php echo e($staff->email); ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="email" class="col-md-4 control-label">Birthday</label>
                                <div class="col-md-6">
                                    <select aria-label="Day" name="birthday_day" title="Day" class="form-control input-inline">
                                        <option value="0">Day</option>
                                        <?php for($i = 1; $i <= 31; $i++): ?>
                                            <option value="<?php echo e($i); ?>" <?php echo e(($staff->birthday_day == $i) ? 'selected=selected':''); ?> ><?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                    <select aria-label="Month" name="birthday_month" title="Month" class="form-control input-inline">
                                        <option value="0">Month</option>
                                        <option value="1" <?php echo e(($staff->birthday_month == 1) ? 'selected=selected':''); ?> >Jan</option>
                                        <option value="2" <?php echo e(($staff->birthday_month == 2) ? 'selected=selected':''); ?> >Feb</option>
                                        <option value="3" <?php echo e(($staff->birthday_month == 3) ? 'selected=selected':''); ?> >Mar</option>
                                        <option value="4" <?php echo e(($staff->birthday_month == 4) ? 'selected=selected':''); ?> >Apr</option>
                                        <option value="5" <?php echo e(($staff->birthday_month == 5) ? 'selected=selected':''); ?> >May</option>
                                        <option value="6" <?php echo e(($staff->birthday_month == 6) ? 'selected=selected':''); ?> >Jun</option>
                                        <option value="7" <?php echo e(($staff->birthday_month == 7) ? 'selected=selected':''); ?> >Jul</option>
                                        <option value="8" <?php echo e(($staff->birthday_month == 8) ? 'selected=selected':''); ?> >Aug</option>
                                        <option value="9" <?php echo e(($staff->birthday_month == 9) ? 'selected=selected':''); ?> >Sept</option>
                                        <option value="10" <?php echo e(($staff->birthday_month == 10) ? 'selected=selected':''); ?> >Oct</option>
                                        <option value="11" <?php echo e(($staff->birthday_month == 11) ? 'selected=selected':''); ?> >Nov</option>
                                        <option value="12" <?php echo e(($staff->birthday_month == 12) ? 'selected=selected':''); ?> >Dec</option>
                                    </select>
                                    <select aria-label="Year" name="birthday_year" title="Year" class="form-control input-inline">
                                        <option value="0">Year</option>
                                        <?php for($i = 2017; $i >= 1905; $i--): ?>
                                            <option value="<?php echo e($i); ?>" <?php echo e(($staff->birthday_year == $i) ? 'selected=selected':''); ?> ><?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>

                                </div>
                            </div>

                            <div class="form-group">
                                <label for="current_address" class="col-md-4 control-label">Country</label>

                                <div class="col-md-6">
                                    <select class="form-control input-inline" name="country">
                                        <option value="18" <?php echo e(($staff->country_id == 18) ? 'selected=selected':''); ?> >Bangldesh</option>
                                        <option value="99" <?php echo e(($staff->country_id == 99) ? 'selected=selected':''); ?> >India</option>
                                        <option value="223" <?php echo e(($staff->country_id == 223) ? 'selected=selected':''); ?> >USA</option>
                                        <option value="44" <?php echo e(($staff->country_id == 44) ? 'selected=selected':''); ?> >China</option>
                                        <option value="113" <?php echo e(($staff->country_id == 113) ? 'selected=selected':''); ?> >Korea</option>
                                        <option value="114" <?php echo e(($staff->country_id == 114) ? 'selected=selected':''); ?> >Kuwait</option>
                                        <option value="162" <?php echo e(($staff->country_id == 162) ? 'selected=selected':''); ?> >Pakistan</option>
                                        <option value="196" <?php echo e(($staff->country_id == 196) ? 'selected=selected':''); ?> >Srilaka</option>
                                        <option value="222" <?php echo e(($staff->country_id == 222) ? 'selected=selected':''); ?> >UK</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="current_address" class="col-md-4 control-label">Current Address</label>
                                <div class="col-md-6">
                                    <input id="current_address" type="text" class="form-control" name="current_address" value="<?php echo e($staff->current_address); ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="permanent_address" class="col-md-4 control-label">Permanent Address</label>
                                <div class="col-md-6">
                                    <input id="permanent_address" type="text" class="form-control" name="permanent_address" value="<?php echo e($staff->permanent_address); ?>">
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="status" class="col-md-4 control-label">Status</label>
                                <div class="col-md-6">
                                    <select class="form-control" name="status" required autofocus>
                                        <option value="1" <?php echo e(($staff->status == 1) ? 'selected=selected':''); ?> >Enable</option>
                                        <option value="0" <?php echo e(($staff->status == 0) ? 'selected=selected':''); ?> >Disable</option>
                                    </select>
                                </div>
                            </div>

                        </div>
                        <!-- end row -->

                        <!-- end wizard step-1 -->

                        <!-- #modal-alert -->
                        <div class="modal fade" id="modal-alert">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                        <h4 class="modal-title">Staff Creation</h4>
                                    </div>
                                    <div class="modal-body">
                                        <div class="alert alert-success m-b-0">
                                            <h4><i class="fa fa-info-circle"></i> Successfully Staff Updated</h4>
                                            <p></p>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <a href="javascript:;" class="btn btn-sm btn-success" data-dismiss="modal">Done</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="panel-footer">
                    <div class="row">
                        <div class="col-md-4"></div>
                        <div class="col-md-6">
                            <a href="<?php echo e(url("/admin/staffs/profile/$staff->id/update")); ?>" class="btn btn-primary"><span class="glyphicon glyphicon-new-window" aria-hidden="true"></span> Update </a>
                            <button type="button" class="btn btn-danger btn_delete" data-id="<?php echo e($staff->id); ?>"><span class="glyphicon glyphicon-remove-circle" aria-hidden="true"></span> Delete </button>
                        </div>
                    </div>

                </div>
            </div>
            <!-- end: staff view -->
        </div>
        <!-- end col-8 -->
        <!-- start col-8 -->
        <div class="col-md-6">
            <!-- begin panel -->
            <div class="panel panel-primary" data-sortable-id="ui-widget-15">
                <div class="panel-heading">
                    <div class="panel-heading-btn">
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-repeat"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger" data-click="panel-remove"><i class="fa fa-times"></i></a>
                    </div>
                    <h4 class="panel-title">Finger Print</h4>
                </div>
                <div class="panel-body" style="position: relative;">
                    <div class="overlay"></div>
                    <form action="#" method="POST" name="" class="form-horizontal">
                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Finger Print ID</label>
                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" name="fps_id" value="<?php echo e($staff->fps_id); ?>" required autofocus>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <!-- end panel -->
        </div>
        <!-- end col-8 -->

    </div>
    <!-- end row -->
</div>
<!-- end #content -->
<!-- start : staff registration -->
<script>
    $(document).ready(function() {

        /*
         * Start : Staff Update
         * */

        $(".staff_update").on('click','.btn_update',function()
        {
            var _token                  = $("input[name=_token]").val();
            var name                    = $(".staff_update input[name=name]").val();
            var department              = $(".staff_update select[name=department]").val();
            var designation             = $(".staff_update select[name=designation]").val();

            var joining_date_day        = $(".staff_update select[name=joining_date_day]").val();
            var joining_date_month      = $(".staff_update select[name=joining_date_month]").val();
            var joining_date_year       = $(".staff_update select[name=joining_date_year]").val();

            var current_status          = $(".staff_update select[name=current_status]").val();
            var username                = $(".staff_update input[name=username]").val();
            var password                = $(".staff_update input[name=password]").val();
            var mobile_number           = $(".staff_update input[name=mobile_number]").val();
            var email                   = $(".staff_update input[name=email]").val();

            var birthday_day            = $(".staff_update select[name=birthday_day]").val();
            var birthday_month          = $(".staff_update select[name=birthday_month]").val();
            var birthday_year           = $(".staff_update select[name=birthday_year]").val();

            var country                 = $(".staff_update select[name=country]").val();
            var current_address         = $(".staff_update input[name=current_address]").val();
            var permanent_address       = $(".staff_update input[name=permanent_address]").val();
            var status                  = $(".staff_update select[name=status]").val();

            var info = {

                _token                  : _token,
                name                    : name,
                department              : department,
                designation             : designation,

                joining_date_day        : joining_date_day,
                joining_date_month      : joining_date_month,
                joining_date_year       : joining_date_year,

                current_status          : current_status,
                username                : username,
                password                : password,
                mobile_number           : mobile_number,
                email                   : email,

                birthday_day            : birthday_day,
                birthday_month          : birthday_month,
                birthday_year           : birthday_year,

                country                 : country,
                current_address         : current_address,
                permanent_address       : permanent_address,
                status                  : status
            };

            request.method   = "POST"                                           ;
            request.route    = 'admin/staffs/profile/<?php echo e($staff->id); ?>/update'     ;
            request.action   = ''                                               ;
            request.data     = info                                             ;
            request.sync     = true                                             ;

            var response = ajaxapp.request('$("#modal-alert").modal("show");','');
            //setTimeout(function(){ FPS_StatusGetCon = true; FPS_Status() },1000);
        });
        /*
         * end : Staff Update
         *
         * 
         * */

        /*
         * Start : FPS Direct Scan
         * */

        $(".staff_update").on('click','.btn_fpsdirectscan',function()
        {
            var _token                  = $("input[name=_token]").val();

            var info = {

                _token : _token
            };

            request.method   = "POST"                                                       ;
            request.route    = 'admin/staffs/profile/{{$staff->id}/update/fpsdirectscan'    ;
            request.action   = ''                                                           ;
            request.data     = info                                                         ;
            request.sync     = true                                                         ;

            var response = ajaxapp.request('$("#modal-alert").modal("show");','');
            //setTimeout(function(){ FPS_StatusGetCon = true; FPS_Status() },1000);
        });
        /*
         * end : FPS Direct Scan
         *
         * 
         * */

    });
</script>
<!-- end : staff registration -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>