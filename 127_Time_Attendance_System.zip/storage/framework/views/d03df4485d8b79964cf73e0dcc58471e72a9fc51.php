<?php $__env->startSection('content'); ?>
<!-- begin #content -->
<div id="content" class="content">
    <!-- begin breadcrumb -->
    <ol class="breadcrumb pull-right">
        <li><a href="javascript:;">Home</a></li>
        <li class="active">Dashboard</li>
    </ol>
    <!-- end breadcrumb -->
    <!-- begin page-header -->
    <h1 class="page-header">Dashboard <small>header small text goes here...</small></h1>
    <!-- end page-header -->

    <!-- begin row -->
    <div class="row">
        <!-- begin col-3 -->
        <div class="col-md-3 col-sm-6">
            <div class="widget widget-stats bg-green">
                <div class="stats-icon"><i class="fa fa-desktop"></i></div>
                <div class="stats-info">
                    <h4>TOTAL STUDENTS</h4>
                    <p>3,291,922</p>
                </div>
                <div class="stats-link">
                    <a href="javascript:;">View Detail <i class="fa fa-arrow-circle-o-right"></i></a>
                </div>
            </div>
        </div>
        <!-- end col-3 -->
        <!-- begin col-3 -->
        <div class="col-md-3 col-sm-6">
            <div class="widget widget-stats bg-blue">
                <div class="stats-icon"><i class="fa fa-chain-broken"></i></div>
                <div class="stats-info">
                    <h4>BOUNCE RATE</h4>
                    <p>20.44%</p>
                </div>
                <div class="stats-link">
                    <a href="javascript:;">View Detail <i class="fa fa-arrow-circle-o-right"></i></a>
                </div>
            </div>
        </div>
        <!-- end col-3 -->
        <!-- begin col-3 -->
        <div class="col-md-3 col-sm-6">
            <div class="widget widget-stats bg-purple">
                <div class="stats-icon"><i class="fa fa-users"></i></div>
                <div class="stats-info">
                    <h4>CURRENT STUDENTS</h4>
                    <p>1,291,922</p>
                </div>
                <div class="stats-link">
                    <a href="javascript:;">View Detail <i class="fa fa-arrow-circle-o-right"></i></a>
                </div>
            </div>
        </div>
        <!-- end col-3 -->
        <!-- begin col-3 -->
        <div class="col-md-3 col-sm-6">
            <div class="widget widget-stats bg-red">
                <div class="stats-icon"><i class="fa fa-clock-o"></i></div>
                <div class="stats-info">
                    <h4>AVG TIME ON SITE</h4>
                    <p>00:12:23</p>
                </div>
                <div class="stats-link">
                    <a href="javascript:;">View Detail <i class="fa fa-arrow-circle-o-right"></i></a>
                </div>
            </div>
        </div>
        <!-- end col-3 -->
    </div>
    <!-- end row -->
    <!-- begin row -->
    <div class="row">
        <!-- begin col-8 -->
        <div class="col-md-6">
            <!-- start: registration -->
            <div class="panel panel-inverse">
                <div class="panel-heading">
                    <div class="panel-heading-btn">
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-repeat"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger" data-click="panel-remove"><i class="fa fa-times"></i></a>
                    </div>
                    <h4 class="panel-title">Office Staff Registration</h4>
                </div>
                <div class="panel-body">
                    <form action="#" method="POST" name="" class="form-horizontal form_registration">
                        <div id="">

                            <!-- begin wizard step-1 -->
                            <div class="step-1">

                            </div>
                            <fieldset>
                                <legend class="pull-left width-full">Office Staff Registration</legend>
                                <!-- begin row -->
                                <div class="row">
                                    <?php echo e(csrf_field()); ?>


                                    <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                        <label for="name" class="col-md-4 control-label">Name</label>

                                        <div class="col-md-6">
                                            <input id="name" type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

                                            <?php if($errors->has('name')): ?>
                                                <span class="help-block">
                                                        <strong><?php echo e($errors->first('name')); ?></strong>
                                                    </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group<?php echo e($errors->has('designation') ? ' has-error' : ''); ?>">
                                        <label for="designation" class="col-md-4 control-label">Designation</label>

                                        <div class="col-md-6">
                                            <select class="form-control" name="designation" required autofocus>
                                                <option value="1">Assistant Engineer</option>
                                                <option value="2">Account Office</option>
                                                <option value="2">Sub. Assistant Engineer</option>
                                                <option value="2">Assistant Engineer</option>
                                                <option value="2">Assistant Engineer</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group<?php echo e($errors->has('joining_date') ? ' has-error' : ''); ?>">
                                        <label for="joining_date" class="col-md-4 control-label">Joining Date</label>

                                        <div class="col-md-6">
                                            <input id="joining_date" type="text" class="form-control" name="joining_date" value="<?php echo e(old('joining_date')); ?>" required autofocus>

                                            <?php if($errors->has('joining_date')): ?>
                                                <span class="help-block">
                                                        <strong><?php echo e($errors->first('joining_date')); ?></strong>
                                                    </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group<?php echo e($errors->has('current_status') ? ' has-error' : ''); ?>">
                                        <label for="current_status" class="col-md-4 control-label">Current Status</label>

                                        <div class="col-md-6">
                                            <select class="form-control" name="current_status" required autofocus>
                                                <option value="1">Active</option>
                                                <option value="2">Leave</option>
                                                <option value="2">Suspand</option>
                                                <option value="2">Temporary Leave</option>
                                                <option value="2">Temporary Suspand</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
                                        <label for="username" class="col-md-4 control-label">Username</label>

                                        <div class="col-md-6">
                                            <input id="username" type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" required autofocus>

                                            <?php if($errors->has('username')): ?>
                                                <span class="help-block">
                                                        <strong><?php echo e($errors->first('username')); ?></strong>
                                                    </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                        <label for="password" class="col-md-4 control-label">Password</label>

                                        <div class="col-md-6">
                                            <input id="password" type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" required autofocus>

                                            <?php if($errors->has('password')): ?>
                                                <span class="help-block">
                                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                                    </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group<?php echo e($errors->has('mobile_number') ? ' has-error' : ''); ?>">
                                        <label for="mobile_number" class="col-md-4 control-label">Mobile Number</label>

                                        <div class="col-md-6">
                                            <input id="mobile_number" type="text" class="form-control" name="mobile_number" value="<?php echo e(old('mobile_number')); ?>" required autofocus>

                                            <?php if($errors->has('mobile_number')): ?>
                                                <span class="help-block">
                                                        <strong><?php echo e($errors->first('mobile_number')); ?></strong>
                                                    </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                        <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                                        <div class="col-md-6">
                                            <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>

                                            <?php if($errors->has('email')): ?>
                                                <span class="help-block">
                                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                                    </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group<?php echo e($errors->has('current_address') ? ' has-error' : ''); ?>">
                                        <label for="current_address" class="col-md-4 control-label">Current Address</label>

                                        <div class="col-md-6">
                                            <input id="current_address" type="text" class="form-control" name="current_address" required>

                                            <?php if($errors->has('current_address')): ?>
                                                <span class="help-block">
                                                        <strong><?php echo e($errors->first('current_address')); ?></strong>
                                                    </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group<?php echo e($errors->has('permanent_address') ? ' has-error' : ''); ?>">
                                        <label for="permanent_address" class="col-md-4 control-label">Permanent Address</label>

                                        <div class="col-md-6">
                                            <input id="permanent_address" type="text" class="form-control" name="permanent_address" required>

                                            <?php if($errors->has('permanent_address')): ?>
                                                <span class="help-block">
                                                        <strong><?php echo e($errors->first('permanent_address')); ?></strong>
                                                    </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group<?php echo e($errors->has('status') ? ' has-error' : ''); ?>">
                                        <label for="status" class="col-md-4 control-label">Status</label>

                                        <div class="col-md-6">

                                            <select class="form-control" name="status" required autofocus>
                                                <option value="0">Enable</option>
                                                <option value="1">Disable</option>
                                            </select>
                                        </div>
                                    </div>

                                </div>
                                <!-- end row -->
                            </fieldset>
                            <button type="button" class="btn btn-primary center-block next">Next to Scan Finger print and Registration <span class="glyphicon glyphicon-arrow-down" aria-hidden="true"></span></button>
                            <!-- end wizard step-1 -->
                            <!-- begin wizard step-2 -->
                            <fieldset>
                                <legend class="pull-left width-full">Finger Print Status</legend>
                                <!-- begin row -->

                                <div class="col-md-12">
                                    <textarea class="form-control bg-white FingerPrintStatus" placeholder="Textarea" rows="5" disabled style="opacity: 1;color: #000;font-size: 15px;height:160px"></textarea>
                                </div>
                                <!-- end row -->
                            </fieldset>
                            <!-- end wizard step-2 -->
                            <!-- begin wizard step-4 -->
                            <br><br>
                            <div class="SuccessInfo" style="display: none">
                                <div class="jumbotron m-b-0 text-center">
                                    <h1>Student Created Successfully</h1>
                                    <p class="hide">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris consequat commodo porttitor. Vivamus eleifend, arcu in tincidunt semper, lorem odio molestie lacus, sed malesuada est lacus ac ligula. Aliquam bibendum felis id purus ullamcorper, quis luctus leo sollicitudin. </p>
                                    <p><a class="btn btn-success btn-lg ViewProfile" role="button">View Student Profile</a></p>
                                </div>
                            </div>
                            <!-- end wizard step-4 -->
                            <!-- #modal-alert -->
                            <div class="modal fade" id="modal-alert">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <h4 class="modal-title">Student Creation</h4>
                                        </div>
                                        <div class="modal-body">
                                            <div class="alert alert-success m-b-0">
                                                <h4><i class="fa fa-info-circle"></i> Successfully Student Created</h4>
                                                <p>To update / delete/ / view student info click the link below the registration page</p>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <a href="javascript:;" class="btn btn-sm btn-success" data-dismiss="modal">Done</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <!-- end: registration -->
        </div>
        <div class="col-md-6">
            <!-- start: Demo Data Upload -->
            <div class="panel panel-inverse">
                <div class="panel-heading">
                    <div class="panel-heading-btn">
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-repeat"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger" data-click="panel-remove"><i class="fa fa-times"></i></a>
                    </div>
                    <h4 class="panel-title">Demo Student Update</h4>
                </div>
                <div class="panel-body">
                    <form action="#" method="POST" name="" class="form-horizontal form_demo_update">
                        <div id="">

                            <!-- begin wizard step-1 -->
                            <div class="step-1">

                            </div>
                            <fieldset>
                                <legend class="pull-left width-full">Student Information</legend>
                                <!-- begin row -->
                                <div class="row search">

                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Student ID</label>
                                        <div class="col-md-9">
                                            <div class="input-group">

                                                <input type="text" class="form-control" placeholder="Student ID" name="demo_student_id"/>
                                                <div class="input-group-btn">
                                                    <button type="button" class="btn btn-success demo_student_search_btn">Search Student <span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <!-- end row -->
                                <!-- begin row -->
                                <div class="row hide student_info">
                                    <nav aria-label="...">
                                        <ul class="pager">
                                            <li><button type="button" class="btn btn-warning back"><span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span> Back</button></li>
                                            <li><button type="button" class="btn btn-primary demo_student_update">Update <span class="glyphicon glyphicon-floppy-saved" aria-hidden="true"></span></button></li>
                                        </ul>
                                    </nav>

                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Student ID</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" placeholder="Student ID" name="demo_student_id_disabled" disabled/>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Photo</label>
                                        <div class="col-md-9">
                                            <div class="input-file-con">
                                                <input type="file" name=photo>
                                                <img src="http://localhost/125_Raspberrypi/img/student/200x200.svg" alt="200x200 image" class="img-thumbnail demo_student_photo">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Name</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" placeholder="Name" name="demo_student_name"/>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Father's Name</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" placeholder="Father's Name" name="demo_fathers_name"/>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Mother's Name</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" placeholder="Mother's Name" name="demo_mothers_name"/>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Date of Birth</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" placeholder="Date of Birth" name="demo_date_of_birth" />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Marital Status</label>
                                        <div class="col-md-9">
                                            <select class="form-control" name="demo_marital_status">
                                                <option value="Single">Single</option>
                                                <option value="Married">Married</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Gender</label>
                                        <div class="col-md-9">
                                            <select class="form-control" name="demo_gender">
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Permanent Address</label>
                                        <div class="col-md-9">
                                            <textarea class="form-control" placeholder="Addessr" rows="3" name="demo_permanent_address"></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Present Address</label>
                                        <div class="col-md-9">
                                            <textarea class="form-control" placeholder="Present Addessr" rows="3" name="demo_presemt_address"></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Country</label>
                                        <div class="col-md-9">
                                            <select class="form-control" name="demo_country">
                                                <option value="" selected="selected">Select</option>
                                                <option value="Afghanistan">Afghanistan</option>
                                                <option value="Aringland Islands">Aringland Islands</option>
                                                <option value="Albania">Albania</option>
                                                <option value="Algeria">Algeria</option>
                                                <option value="American Samoa">American Samoa</option>
                                                <option value="Andorra">Andorra</option>
                                                <option value="Angola">Angola</option>
                                                <option value="Anguilla">Anguilla</option>
                                                <option value="Antarctica">Antarctica</option>
                                                <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                                                <option value="Argentina">Argentina</option>
                                                <option value="Armenia">Armenia</option>
                                                <option value="Aruba">Aruba</option>
                                                <option value="Australia">Australia</option>
                                                <option value="Austria">Austria</option>
                                                <option value="Azerbaijan">Azerbaijan</option>
                                                <option value="Bahamas">Bahamas</option>
                                                <option value="Bahrain">Bahrain</option>
                                                <option value="Bangladesh">Bangladesh</option>
                                                <option value="Barbados">Barbados</option>
                                                <option value="Belarus">Belarus</option>
                                                <option value="Belgium">Belgium</option>
                                                <option value="Belize">Belize</option>
                                                <option value="Benin">Benin</option>
                                                <option value="Bermuda">Bermuda</option>
                                                <option value="Bhutan">Bhutan</option>
                                                <option value="Bolivia, Plurinational State of">Bolivia, Plurinational State of</option>
                                                <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                                                <option value="Botswana">Botswana</option>
                                                <option value="Bouvet Island">Bouvet Island</option>
                                                <option value="Brazil">Brazil</option>
                                                <option value="British Indian Ocean Territory">British Indian Ocean Territory</option>
                                                <option value="Brunei Darussalam">Brunei Darussalam</option>
                                                <option value="Bulgaria">Bulgaria</option>
                                                <option value="Burkina Faso">Burkina Faso</option>
                                                <option value="Burundi">Burundi</option>
                                                <option value="Cambodia">Cambodia</option>
                                                <option value="Cameroon">Cameroon</option>
                                                <option value="Canada">Canada</option>
                                                <option value="Cape Verde">Cape Verde</option>
                                                <option value="Cayman Islands">Cayman Islands</option>
                                                <option value="Central African Republic">Central African Republic</option>
                                                <option value="Chad">Chad</option>
                                                <option value="Chile">Chile</option>
                                                <option value="China">China</option>
                                                <option value="Christmas Island">Christmas Island</option>
                                                <option value="Cocos (Keeling) Islands">Cocos (Keeling) Islands</option>
                                                <option value="Colombia">Colombia</option>
                                                <option value="Comoros">Comoros</option>
                                                <option value="Congo">Congo</option>
                                                <option value="Congo, the Democratic Republic of the">Congo, the Democratic Republic of the</option>
                                                <option value="Cook Islands">Cook Islands</option>
                                                <option value="Costa Rica">Costa Rica</option>
                                                <option value="Croatia">Croatia</option>
                                                <option value="Cuba">Cuba</option>
                                                <option value="Cyprus">Cyprus</option>
                                                <option value="Czech Republic">Czech Republic</option>
                                                <option value="Denmark">Denmark</option>
                                                <option value="Djibouti">Djibouti</option>
                                                <option value="Dominica">Dominica</option>
                                                <option value="Dominican Republic">Dominican Republic</option>
                                                <option value="Ecuador">Ecuador</option>
                                                <option value="Egypt">Egypt</option>
                                                <option value="El Salvador">El Salvador</option>
                                                <option value="Equatorial Guinea">Equatorial Guinea</option>
                                                <option value="Eritrea">Eritrea</option>
                                                <option value="Estonia">Estonia</option>
                                                <option value="Ethiopia">Ethiopia</option>
                                                <option value="Falkland Islands (Malvinas)">Falkland Islands (Malvinas)</option>
                                                <option value="Faroe Islands">Faroe Islands</option>
                                                <option value="Fiji">Fiji</option>
                                                <option value="Finland">Finland</option>
                                                <option value="France">France</option>
                                                <option value="French Guiana">French Guiana</option>
                                                <option value="French Polynesia">French Polynesia</option>
                                                <option value="French Southern Territories">French Southern Territories</option>
                                                <option value="Gabon">Gabon</option>
                                                <option value="Gambia">Gambia</option>
                                                <option value="Georgia">Georgia</option>
                                                <option value="Germany">Germany</option>
                                                <option value="Ghana">Ghana</option>
                                                <option value="Gibraltar">Gibraltar</option>
                                                <option value="Greece">Greece</option>
                                                <option value="Greenland">Greenland</option>
                                                <option value="Grenada">Grenada</option>
                                                <option value="Guadeloupe">Guadeloupe</option>
                                                <option value="Guam">Guam</option>
                                                <option value="Guatemala">Guatemala</option>
                                                <option value="Guernsey">Guernsey</option>
                                                <option value="Guinea">Guinea</option>
                                                <option value="Guinea-Bissau">Guinea-Bissau</option>
                                                <option value="Guyana">Guyana</option>
                                                <option value="Haiti">Haiti</option>
                                                <option value="Heard Island and McDonald Islands">Heard Island and McDonald Islands</option>
                                                <option value="Holy See (Vatican City State)">Holy See (Vatican City State)</option>
                                                <option value="Honduras">Honduras</option>
                                                <option value="Hong Kong">Hong Kong</option>
                                                <option value="Hungary">Hungary</option>
                                                <option value="Iceland">Iceland</option>
                                                <option value="India">India</option>
                                                <option value="Indonesia">Indonesia</option>
                                                <option value="Iran, Islamic Republic of">Iran, Islamic Republic of</option>
                                                <option value="Iraq">Iraq</option>
                                                <option value="Ireland">Ireland</option>
                                                <option value="Isle of Man">Isle of Man</option>
                                                <option value="Israel">Israel</option>
                                                <option value="Italy">Italy</option>
                                                <option value="Jamaica">Jamaica</option>
                                                <option value="Japan">Japan</option>
                                                <option value="Jersey">Jersey</option>
                                                <option value="Jordan">Jordan</option>
                                                <option value="Kazakhstan">Kazakhstan</option>
                                                <option value="Kenya">Kenya</option>
                                                <option value="Kiribati">Kiribati</option>
                                                <option value="Korea, Democratic People's Republic of">Korea, Democratic People's Republic of</option>
                                                <option value="Korea, Republic of">Korea, Republic of</option>
                                                <option value="Kuwait">Kuwait</option>
                                                <option value="Kyrgyzstan">Kyrgyzstan</option>
                                                <option value="Lao People's Democratic Republic">Lao People's Democratic Republic</option>
                                                <option value="Latvia">Latvia</option>
                                                <option value="Lebanon">Lebanon</option>
                                                <option value="Lesotho">Lesotho</option>
                                                <option value="Liberia">Liberia</option>
                                                <option value="Libyan Arab Jamahiriya">Libyan Arab Jamahiriya</option>
                                                <option value="Liechtenstein">Liechtenstein</option>
                                                <option value="Lithuania">Lithuania</option>
                                                <option value="Luxembourg">Luxembourg</option>
                                                <option value="Macao">Macao</option>
                                                <option value="Macedonia, the former Yugoslav Republic of">Macedonia, the former Yugoslav Republic of</option>
                                                <option value="Madagascar">Madagascar</option>
                                                <option value="Malawi">Malawi</option>
                                                <option value="Malaysia">Malaysia</option>
                                                <option value="Maldives">Maldives</option>
                                                <option value="Mali">Mali</option>
                                                <option value="Malta">Malta</option>
                                                <option value="Marshall Islands">Marshall Islands</option>
                                                <option value="Martinique">Martinique</option>
                                                <option value="Mauritania">Mauritania</option>
                                                <option value="Mauritius">Mauritius</option>
                                                <option value="Mayotte">Mayotte</option>
                                                <option value="Mexico">Mexico</option>
                                                <option value="Micronesia, Federated States of">Micronesia, Federated States of</option>
                                                <option value="Moldova, Republic of">Moldova, Republic of</option>
                                                <option value="Monaco">Monaco</option>
                                                <option value="Mongolia">Mongolia</option>
                                                <option value="Montenegro">Montenegro</option>
                                                <option value="Montserrat">Montserrat</option>
                                                <option value="Morocco">Morocco</option>
                                                <option value="Mozambique">Mozambique</option>
                                                <option value="Myanmar">Myanmar</option>
                                                <option value="Namibia">Namibia</option>
                                                <option value="Nauru">Nauru</option>
                                                <option value="Nepal">Nepal</option>
                                                <option value="Netherlands">Netherlands</option>
                                                <option value="Netherlands Antilles">Netherlands Antilles</option>
                                                <option value="New Caledonia">New Caledonia</option>
                                                <option value="New Zealand">New Zealand</option>
                                                <option value="Nicaragua">Nicaragua</option>
                                                <option value="Niger">Niger</option>
                                                <option value="Nigeria">Nigeria</option>
                                                <option value="Niue">Niue</option>
                                                <option value="Norfolk Island">Norfolk Island</option>
                                                <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                                                <option value="Norway">Norway</option>
                                                <option value="Oman">Oman</option>
                                                <option value="Pakistan">Pakistan</option>
                                                <option value="Palau">Palau</option>
                                                <option value="Palestinian Territory, Occupied">Palestinian Territory, Occupied</option>
                                                <option value="Panama">Panama</option>
                                                <option value="Papua New Guinea">Papua New Guinea</option>
                                                <option value="Paraguay">Paraguay</option>
                                                <option value="Peru">Peru</option>
                                                <option value="Philippines">Philippines</option>
                                                <option value="Pitcairn">Pitcairn</option>
                                                <option value="Poland">Poland</option>
                                                <option value="Portugal">Portugal</option>
                                                <option value="Puerto Rico">Puerto Rico</option>
                                                <option value="Qatar">Qatar</option>
                                                <option value="Romania">Romania</option>
                                                <option value="Russian Federation">Russian Federation</option>
                                                <option value="Rwanda">Rwanda</option>
                                                <option value="Saint Helena, Ascension and Tristan da Cunha">Saint Helena, Ascension and Tristan da Cunha</option>
                                                <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                                                <option value="Saint Lucia">Saint Lucia</option>
                                                <option value="Saint Martin (French part)">Saint Martin (French part)</option>
                                                <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                                                <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                                                <option value="Samoa">Samoa</option>
                                                <option value="San Marino">San Marino</option>
                                                <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                                                <option value="Saudi Arabia">Saudi Arabia</option>
                                                <option value="Senegal">Senegal</option>
                                                <option value="Serbia">Serbia</option>
                                                <option value="Seychelles">Seychelles</option>
                                                <option value="Sierra Leone">Sierra Leone</option>
                                                <option value="Singapore">Singapore</option>
                                                <option value="Slovakia">Slovakia</option>
                                                <option value="Slovenia">Slovenia</option>
                                                <option value="Solomon Islands">Solomon Islands</option>
                                                <option value="Somalia">Somalia</option>
                                                <option value="South Africa">South Africa</option>
                                                <option value="South Georgia and the South Sandwich Islands">South Georgia and the South Sandwich Islands</option>
                                                <option value="Spain">Spain</option>
                                                <option value="Sri Lanka">Sri Lanka</option>
                                                <option value="Sudan">Sudan</option>
                                                <option value="Suriname">Suriname</option>
                                                <option value="Svalbard and Jan Mayen">Svalbard and Jan Mayen</option>
                                                <option value="Swaziland">Swaziland</option>
                                                <option value="Sweden">Sweden</option>
                                                <option value="Switzerland">Switzerland</option>
                                                <option value="Syrian Arab Republic">Syrian Arab Republic</option>
                                                <option value="Taiwan, Province of China">Taiwan, Province of China</option>
                                                <option value="Tajikistan">Tajikistan</option>
                                                <option value="Tanzania, United Republic of">Tanzania, United Republic of</option>
                                                <option value="Thailand">Thailand</option>
                                                <option value="Timor-Leste">Timor-Leste</option>
                                                <option value="Togo">Togo</option>
                                                <option value="Tokelau">Tokelau</option>
                                                <option value="Tonga">Tonga</option>
                                                <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                                                <option value="Tunisia">Tunisia</option>
                                                <option value="Turkey">Turkey</option>
                                                <option value="Turkmenistan">Turkmenistan</option>
                                                <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                                                <option value="Tuvalu">Tuvalu</option>
                                                <option value="Uganda">Uganda</option>
                                                <option value="Ukraine">Ukraine</option>
                                                <option value="United Arab Emirates">United Arab Emirates</option>
                                                <option value="United Kingdom">United Kingdom</option>
                                                <option value="United States">United States</option>
                                                <option value="United States Minor Outlying Islands">United States Minor Outlying Islands</option>
                                                <option value="Uruguay">Uruguay</option>
                                                <option value="Uzbekistan">Uzbekistan</option>
                                                <option value="Vanuatu">Vanuatu</option>
                                                <option value="Venezuela, Bolivarian Republic of">Venezuela, Bolivarian Republic of</option>
                                                <option value="Viet Nam">Viet Nam</option>
                                                <option value="Virgin Islands, British">Virgin Islands, British</option>
                                                <option value="Virgin Islands, U.S.">Virgin Islands, U.S.</option>
                                                <option value="Wallis and Futuna">Wallis and Futuna</option>
                                                <option value="Western Sahara">Western Sahara</option>
                                                <option value="Yemen">Yemen</option>
                                                <option value="Zambia">Zambia</option>
                                                <option value="Zimbabwe">Zimbabwe</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Cell Number</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" placeholder="01234567789" name="demo_cell_number" />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Alternet Number</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" placeholder="01234567789" name="demo_alternet_number"/>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">E-mail</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" placeholder="demo@gmail.com" name="demo_email"/>
                                        </div>
                                    </div>


                                    <button type="button" class="btn btn-primary center-block demo_student_update">Update <span class="glyphicon glyphicon-floppy-saved" aria-hidden="true"></span></button>


                                </div>
                                <!-- end row -->
                            </fieldset>

                            <!-- #modal-alert -->
                            <div class="modal fade" id="modal-alert-update">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <h4 class="modal-title">Student Update</h4>
                                        </div>
                                        <div class="modal-body">
                                            <div class="alert alert-success m-b-0">
                                                <h4><i class="fa fa-info-circle"></i> Successfully Student Updated</h4>
                                                <p>Student successfully updated, You can update anytime.</p>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <a href="javascript:;" class="btn btn-sm btn-success" data-dismiss="modal">Done</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <!-- end: Demo Data Upload -->
        </div>
        <div class="col-md-12">
            <!-- start: Demo Data Upload - academic result -->
            <div class="panel panel-inverse">
                <div class="panel-heading">
                    <div class="panel-heading-btn">
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-repeat"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger" data-click="panel-remove"><i class="fa fa-times"></i></a>
                    </div>
                    <h4 class="panel-title">Demo Student Update</h4>
                </div>
                <div class="panel-body">
                    <form action="#" method="POST" name="" class="form-horizontal form_demo_update_academic">
                        <div id="">

                            <!-- begin wizard step-1 -->
                            <div class="step-1">

                            </div>
                            <fieldset>
                                <legend class="pull-left width-full">Academic Result</legend>
                                <!-- begin row -->
                                <div class="row search">

                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Student ID</label>
                                        <div class="col-md-9">
                                            <div class="input-group">

                                                <input type="text" class="form-control" placeholder="Student ID" name="demo_student_id"/>
                                                <div class="input-group-btn">
                                                    <button type="button" class="btn btn-success demo_student_search_btn">Search Student <span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <!-- end row -->
                                <!-- begin row -->
                                <div class="row hide student_info">
                                    <nav aria-label="...">
                                        <ul class="pager">
                                            <li><button type="button" class="btn btn-warning back"><span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span> Back</button></li>
                                        </ul>
                                    </nav>

                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Student ID</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" placeholder="Student ID" name="demo_student_id_disabled" disabled/>
                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Code</th>
                                                <th>Course Title</th>
                                                <th>Credit</th>
                                                <th>Letter Grade</th>
                                                <th>Earned Credit</th>
                                                <th>Grade Point</th>
                                                <th>Semester</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td>CSE151</td>
                                                <td>Computer Fundamentals and Web Technology SecB</td>
                                                <td>3.00</td>
                                                <td>A+</td>
                                                <td>3.00</td>
                                                <td>4.00</td>
                                                <td>Spri 2013</td>
                                            </tr>
                                            <tr>
                                                <td>1</td>
                                                <td>CSE151</td>
                                                <td>Computer Fundamentals and Web Technology SecB</td>
                                                <td>3.00</td>
                                                <td>A+</td>
                                                <td>3.00</td>
                                                <td>4.00</td>
                                                <td>Spri 2013</td>
                                            </tr>
                                            <tr>
                                                <td>1</td>
                                                <td>CSE151</td>
                                                <td>Computer Fundamentals and Web Technology SecB</td>
                                                <td>3.00</td>
                                                <td>A+</td>
                                                <td>3.00</td>
                                                <td>4.00</td>
                                                <td>Spri 2013</td>
                                            </tr>
                                            <tr>
                                                <td>1</td>
                                                <td>CSE151</td>
                                                <td>Computer Fundamentals and Web Technology SecB</td>
                                                <td>3.00</td>
                                                <td>A+</td>
                                                <td>3.00</td>
                                                <td>4.00</td>
                                                <td>Spri 2013</td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <legend class="pull-left width-full">Insert Academic Result</legend>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Course Name</label>
                                        <div class="col-md-9">
                                            <select class="form-control" name="demo_course">
                                                <option credit="0" value="">Select a Course</option>
                                                <option credit="3" value="EEE419">Analog Integrated Circuits</option>
                                                <option credit="3" value="GED117">Bangla</option>
                                                <option credit="3" value="HUM183">Bangladesh Studies</option>
                                                <option credit="3.0" value="EEE445">Biomedical Instrumentation </option>
                                                <option credit="1" value="EEE108">Circuit Simulation Lab</option>
                                                <option credit="3" value="EEE309">Communication Theory </option>
                                                <option credit="1" value="EEE312">Communication Theory Lab</option>
                                                <option credit="3" value="CSE151">Computer Fundamentals and Web Technology</option>
                                                <option credit="3" value="EEE253">Computer Networking and Data Communication</option>
                                                <option credit="3" value="CSE457">Computer Networks</option>
                                                <option credit="1" value="CSE458">Computer Networks Lab</option>
                                                <option credit="2" value="CSE251">Computer Programming</option>
                                                <option credit="1" value="CSE252">Computer Programming Lab</option>
                                                <option credit="3" value="EEE405">Control Systems</option>
                                                <option credit="1" value="EEE406">Control Systems Lab</option>
                                                <option credit="3" value="MAT261">Coordinate Geometry and Vector Analysis</option>
                                                <option credit="3" value="MAT163">Differential and Integral Calculus</option>
                                                <option credit="3" value="ECE437">Digital Communication</option>
                                                <option credit="3" value="EEE427">Digital Communication Electronics</option>
                                                <option credit="1" value="ECE438">Digital Communication Lab</option>
                                                <option credit="3" value="EEE201">Digital Electronics</option>
                                                <option credit="1" value="EEE202">Digital Electronics Lab</option>
                                                <option credit="3" value="EEE421">Digital Integrated Circuits Design</option>
                                                <option credit="1" value="EEE422">Digital Integrated Circuits Design Lab</option>
                                                <option credit="3" value="EEE315">Digital Signal Processing</option>
                                                <option credit="1" value="EEE316">Digital Signal Processing Lab</option>
                                                <option credit="3" value="EEE101">Electrical Circuits I</option>
                                                <option credit="3" value="EEE103">Electrical Circuits II</option>
                                                <option credit="1" value="EEE104">Electrical Circuits Lab</option>
                                                <option credit="3" value="EEE401">Electrical Engineering Materials</option>
                                                <option credit="3" value="EEE205">Electrical Machines I</option>
                                                <option credit="3" value="EEE209">Electrical Machines II</option>
                                                <option credit="1" value="EEE212">Electrical Machines Lab</option>
                                                <option credit="3" value="EEE409">Electrical Power Transmission &amp; Distribu</option>
                                                <option credit="3" value="EEE317">Electrical Services Design and Drafting</option>
                                                <option credit="3" value="PHY173">Electricity, Magnetism &amp; Modern Physics</option>
                                                <option credit="3" value="PHY174">Electricity, Magnetism &amp; Modern Physics Lab</option>
                                                <option credit="3" value="EEE301">Electromagnetic Fields and Waves</option>
                                                <option credit="3" value="EEE105">Electronic Circuits I</option>
                                                <option credit="3" value="EEE203">Electronic Circuits II</option>
                                                <option credit="1" value="EEE204">Electronic Circuits Lab</option>
                                                <option credit="1" value="EEE208">Electronic Measurement &amp; Instrumen lab</option>
                                                <option credit="3" value="EEE207">Electronic Measurement &amp; Instrumentation</option>
                                                <option credit="3" value="CHE175">Engineering Chemistry</option>
                                                <option credit="1" value="CHE176">Engineering Chemistry Lab</option>
                                                <option credit="1" value="EEE102">Engineering Drawing</option>
                                                <option credit="1" value="PHY174">Engineering Physics Lab</option>
                                                <option credit="3" value="HUM181">English I</option>
                                                <option credit="3" value="HUM187">English II</option>
                                                <option credit="3" value="HUM383">Financial &amp; Managerial Accounting</option>
                                                <option credit="3" value="MAT161">Fundamental Mathematics</option>
                                                <option credit="2" value="ME291">Fundamentals of Mechanical Engineering</option>
                                                <option credit="1" value="ME292">Fundamentals of Mechanical Engineering L</option>
                                                <option credit="3" value="EEE415">High Voltage Engineering</option>
                                                <option credit="1" value="EEE416">High Voltage Engineering Lab</option>
                                                <option credit="3" value="HUM481">Industrial and Operation Management</option>
                                                <option credit="3" value="EEE403">Industrial and Power Electronics</option>
                                                <option credit="3" value="EEE461">Industrial and Power Electronics</option>
                                                <option credit="1" value="EEE404">Industrial and Power Electronics Lab</option>
                                                <option credit="3" value="ECE439">Information Theory and Coding</option>
                                                <option credit="3" value="HUM185">International Relation</option>
                                                <option credit="3" value="HUM283">Introduction to Business</option>
                                                <option credit="3" value="HUM281">Introduction to Economics</option>
                                                <option credit="3" value="HUM285">Introduction to Sociology</option>
                                                <option credit="3" value="MAT265">Linear Algebra CV FA</option>
                                                <option credit="3" value="EEE313">Microprocessor and Microcontroller</option>
                                                <option credit="1" value="EEE314">Microprocessor and Microcontroller Lab</option>
                                                <option credit="3" value="CSE453">Microprocessor System Design</option>
                                                <option credit="1" value="CSE454">Microprocessor System Design Lab</option>
                                                <option credit="3" value="ECE435">Microwave Engineering</option>
                                                <option credit="3" value="HUM385">Modern Civilization</option>
                                                <option credit="3" value="CSE459">Multimedia Communications</option>
                                                <option credit="2" value="MAT267">Numerical Methods and Analysis</option>
                                                <option credit="3" value="ECE431">Optical Fiber Communication</option>
                                                <option credit="1" value="ECE432">Optical Fiber Communication Lab</option>
                                                <option credit="3" value="EEE417">Optoelectronics</option>
                                                <option credit="3" value="MAT165">Ordinary and Partial Differential Equati</option>
                                                <option credit="3" value="EEE411">Power Plant Engineering</option>
                                                <option credit="3" value="EEE303">Power System I</option>
                                                <option credit="3" value="EEE407">Power System II</option>
                                                <option credit="1" value="EEE408">Power System Lab</option>
                                                <option credit="3" value="EEE413">Power System Protection</option>
                                                <option credit="1" value="EEE414">Power System Protection Lab</option>
                                                <option credit="3" value="MAT263">Probability and Statistics</option>
                                                <option credit="3" value="EEE425">Processing and Fabrication Technology</option>
                                                <option credit="3" value="HUM483">Professional Ethics</option>
                                                <option credit="6" value="EEE490">Project</option>
                                                <option credit="3" value="CSE455">Real Time Computer System</option>
                                                <option credit="3" value="EEE305">Signals &amp; Systems</option>
                                                <option credit="3" value="CSE451">Software Engineering</option>
                                                <option credit="1" value="CSE452">Software Engineering Lab</option>
                                                <option credit="3" value="EEE307">Solid State Devices</option>
                                                <option credit="3" value="ECE433">Telecommunication Engineering</option>
                                                <option credit="1" value="ECE434">Telecommunication Engineering Lab</option>
                                                <option credit="3" value="GED101">The Four Skills of Communication in English I</option>
                                                <option credit="3" value="GED103">The Four Skills of Communication in English II</option>
                                                <option credit="2" value="EEE291">Thermodynamics, Refrigerator and Air Conditioning</option>
                                                <option credit="1" value="EEE292">Thermodynamics, Refrigerator and Air Conditioning Lab</option>
                                                <option credit="3" value="EEE423">VLSI</option>
                                                <option credit="1" value="EEE424">VLSI Lab</option>
                                                <option credit="3" value="PHY171">Waves, Optics &amp; Thermodynamics</option>
                                                <option credit="1" value="PHY172">Waves, Optics &amp; Thermodynamics Lab</option>
                                                <option credit="3" value="ECE429">Wireless &amp; Satellite Communication</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Semester</label>
                                        <div class="col-md-9">
                                            <select name="semester" class="form-control">
                                                <option value="">Select</option>
                                                <option value="Spring">Spring</option>
                                                <option value="Summer">Summer</option>
                                                <option value="Fall">Fall</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Year</label>
                                        <div class="col-md-9">
                                            <select name="year" class="form-control">
                                                <option value="">Select</option>
                                                <option value="2017"> 2017</option>
                                                <option value="2016"> 2016</option>
                                                <option value="2015"> 2015</option>
                                                <option value="2014"> 2014</option>
                                                <option value="2013"> 2013</option>
                                                <option value="2012"> 2012</option>
                                                <option value="2011"> 2011</option>
                                                <option value="2010"> 2010</option>
                                                <option value="2009"> 2009</option>
                                                <option value="2008"> 2008</option>
                                                <option value="2007"> 2007</option>
                                                <option value="2006"> 2006</option>
                                                <option value="2005"> 2005</option>
                                                <option value="2004"> 2004</option>
                                                <option value="2003"> 2003</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Grade Point</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" placeholder="4.00" name="demo_grade_point" />
                                        </div>
                                    </div>

                                    <button type="button" class="btn btn-primary center-block demo_student_update">Insert <span class="glyphicon glyphicon-floppy-saved" aria-hidden="true"></span></button>


                                </div>
                                <!-- end row -->
                            </fieldset>

                            <!-- #modal-alert -->
                            <div class="modal fade" id="modal-alert-update">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <h4 class="modal-title">Student Update</h4>
                                        </div>
                                        <div class="modal-body">
                                            <div class="alert alert-success m-b-0">
                                                <h4><i class="fa fa-info-circle"></i> Successfully Student Updated</h4>
                                                <p>Student successfully updated, You can update anytime.</p>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <a href="javascript:;" class="btn btn-sm btn-success" data-dismiss="modal">Done</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <!-- end: Demo Data Upload - academic result -->
            <!-- start: Demo Data Upload - current semester -->
            <div class="panel panel-inverse">
                <div class="panel-heading">
                    <div class="panel-heading-btn">
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-repeat"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger" data-click="panel-remove"><i class="fa fa-times"></i></a>
                    </div>
                    <h4 class="panel-title">Demo Student Update</h4>
                </div>
                <div class="panel-body">
                    <form action="#" method="POST" name="" class="form-horizontal form_demo_update_current_semester">
                        <div id="">

                            <!-- begin wizard step-1 -->
                            <div class="step-1">

                            </div>
                            <fieldset>
                                <legend class="pull-left width-full">Current Semester</legend>
                                <!-- begin row -->
                                <div class="row search">

                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Student ID</label>
                                        <div class="col-md-9">
                                            <div class="input-group">

                                                <input type="text" class="form-control" placeholder="Student ID" name="demo_student_id"/>
                                                <div class="input-group-btn">
                                                    <button type="button" class="btn btn-success demo_student_search_btn">Search Student <span class="glyphicon glyphicon-search" aria-hidden="true"></span></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <!-- end row -->
                                <!-- begin row -->
                                <div class="row hide student_info">
                                    <nav aria-label="...">
                                        <ul class="pager">
                                            <li><button type="button" class="btn btn-warning back"><span class="glyphicon glyphicon-arrow-left" aria-hidden="true"></span> Back</button></li>
                                        </ul>
                                    </nav>

                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Student ID</label>
                                        <div class="col-md-9">
                                            <input type="text" class="form-control" placeholder="Student ID" name="demo_student_id_disabled" disabled/>
                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table table-striped">
                                            <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Code</th>
                                                <th>Course Title</th>
                                                <th>Credit</th>
                                                <th>Semester</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td>CSE151</td>
                                                <td>Computer Fundamentals and Web Technology SecB</td>
                                                <td>3.00</td>
                                                <td>A+</td>
                                                <td>3.00</td>
                                                <td>4.00</td>
                                                <td>Spri 2013</td>
                                            </tr>
                                            <tr>
                                                <td>1</td>
                                                <td>CSE151</td>
                                                <td>Computer Fundamentals and Web Technology SecB</td>
                                                <td>3.00</td>
                                                <td>A+</td>
                                                <td>3.00</td>
                                                <td>4.00</td>
                                                <td>Spri 2013</td>
                                            </tr>
                                            <tr>
                                                <td>1</td>
                                                <td>CSE151</td>
                                                <td>Computer Fundamentals and Web Technology SecB</td>
                                                <td>3.00</td>
                                                <td>A+</td>
                                                <td>3.00</td>
                                                <td>4.00</td>
                                                <td>Spri 2013</td>
                                            </tr>
                                            <tr>
                                                <td>1</td>
                                                <td>CSE151</td>
                                                <td>Computer Fundamentals and Web Technology SecB</td>
                                                <td>3.00</td>
                                                <td>A+</td>
                                                <td>3.00</td>
                                                <td>4.00</td>
                                                <td>Spri 2013</td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <legend class="pull-left width-full">Insert Academic Result</legend>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Course Name</label>
                                        <div class="col-md-9">
                                            <select class="form-control" name="demo_course">
                                                <option credit="0" value="">Select a Course</option>
                                                <option credit="3" value="EEE419">Analog Integrated Circuits</option>
                                                <option credit="3" value="GED117">Bangla</option>
                                                <option credit="3" value="HUM183">Bangladesh Studies</option>
                                                <option credit="3.0" value="EEE445">Biomedical Instrumentation </option>
                                                <option credit="1" value="EEE108">Circuit Simulation Lab</option>
                                                <option credit="3" value="EEE309">Communication Theory </option>
                                                <option credit="1" value="EEE312">Communication Theory Lab</option>
                                                <option credit="3" value="CSE151">Computer Fundamentals and Web Technology</option>
                                                <option credit="3" value="EEE253">Computer Networking and Data Communication</option>
                                                <option credit="3" value="CSE457">Computer Networks</option>
                                                <option credit="1" value="CSE458">Computer Networks Lab</option>
                                                <option credit="2" value="CSE251">Computer Programming</option>
                                                <option credit="1" value="CSE252">Computer Programming Lab</option>
                                                <option credit="3" value="EEE405">Control Systems</option>
                                                <option credit="1" value="EEE406">Control Systems Lab</option>
                                                <option credit="3" value="MAT261">Coordinate Geometry and Vector Analysis</option>
                                                <option credit="3" value="MAT163">Differential and Integral Calculus</option>
                                                <option credit="3" value="ECE437">Digital Communication</option>
                                                <option credit="3" value="EEE427">Digital Communication Electronics</option>
                                                <option credit="1" value="ECE438">Digital Communication Lab</option>
                                                <option credit="3" value="EEE201">Digital Electronics</option>
                                                <option credit="1" value="EEE202">Digital Electronics Lab</option>
                                                <option credit="3" value="EEE421">Digital Integrated Circuits Design</option>
                                                <option credit="1" value="EEE422">Digital Integrated Circuits Design Lab</option>
                                                <option credit="3" value="EEE315">Digital Signal Processing</option>
                                                <option credit="1" value="EEE316">Digital Signal Processing Lab</option>
                                                <option credit="3" value="EEE101">Electrical Circuits I</option>
                                                <option credit="3" value="EEE103">Electrical Circuits II</option>
                                                <option credit="1" value="EEE104">Electrical Circuits Lab</option>
                                                <option credit="3" value="EEE401">Electrical Engineering Materials</option>
                                                <option credit="3" value="EEE205">Electrical Machines I</option>
                                                <option credit="3" value="EEE209">Electrical Machines II</option>
                                                <option credit="1" value="EEE212">Electrical Machines Lab</option>
                                                <option credit="3" value="EEE409">Electrical Power Transmission &amp; Distribu</option>
                                                <option credit="3" value="EEE317">Electrical Services Design and Drafting</option>
                                                <option credit="3" value="PHY173">Electricity, Magnetism &amp; Modern Physics</option>
                                                <option credit="3" value="PHY174">Electricity, Magnetism &amp; Modern Physics Lab</option>
                                                <option credit="3" value="EEE301">Electromagnetic Fields and Waves</option>
                                                <option credit="3" value="EEE105">Electronic Circuits I</option>
                                                <option credit="3" value="EEE203">Electronic Circuits II</option>
                                                <option credit="1" value="EEE204">Electronic Circuits Lab</option>
                                                <option credit="1" value="EEE208">Electronic Measurement &amp; Instrumen lab</option>
                                                <option credit="3" value="EEE207">Electronic Measurement &amp; Instrumentation</option>
                                                <option credit="3" value="CHE175">Engineering Chemistry</option>
                                                <option credit="1" value="CHE176">Engineering Chemistry Lab</option>
                                                <option credit="1" value="EEE102">Engineering Drawing</option>
                                                <option credit="1" value="PHY174">Engineering Physics Lab</option>
                                                <option credit="3" value="HUM181">English I</option>
                                                <option credit="3" value="HUM187">English II</option>
                                                <option credit="3" value="HUM383">Financial &amp; Managerial Accounting</option>
                                                <option credit="3" value="MAT161">Fundamental Mathematics</option>
                                                <option credit="2" value="ME291">Fundamentals of Mechanical Engineering</option>
                                                <option credit="1" value="ME292">Fundamentals of Mechanical Engineering L</option>
                                                <option credit="3" value="EEE415">High Voltage Engineering</option>
                                                <option credit="1" value="EEE416">High Voltage Engineering Lab</option>
                                                <option credit="3" value="HUM481">Industrial and Operation Management</option>
                                                <option credit="3" value="EEE403">Industrial and Power Electronics</option>
                                                <option credit="3" value="EEE461">Industrial and Power Electronics</option>
                                                <option credit="1" value="EEE404">Industrial and Power Electronics Lab</option>
                                                <option credit="3" value="ECE439">Information Theory and Coding</option>
                                                <option credit="3" value="HUM185">International Relation</option>
                                                <option credit="3" value="HUM283">Introduction to Business</option>
                                                <option credit="3" value="HUM281">Introduction to Economics</option>
                                                <option credit="3" value="HUM285">Introduction to Sociology</option>
                                                <option credit="3" value="MAT265">Linear Algebra CV FA</option>
                                                <option credit="3" value="EEE313">Microprocessor and Microcontroller</option>
                                                <option credit="1" value="EEE314">Microprocessor and Microcontroller Lab</option>
                                                <option credit="3" value="CSE453">Microprocessor System Design</option>
                                                <option credit="1" value="CSE454">Microprocessor System Design Lab</option>
                                                <option credit="3" value="ECE435">Microwave Engineering</option>
                                                <option credit="3" value="HUM385">Modern Civilization</option>
                                                <option credit="3" value="CSE459">Multimedia Communications</option>
                                                <option credit="2" value="MAT267">Numerical Methods and Analysis</option>
                                                <option credit="3" value="ECE431">Optical Fiber Communication</option>
                                                <option credit="1" value="ECE432">Optical Fiber Communication Lab</option>
                                                <option credit="3" value="EEE417">Optoelectronics</option>
                                                <option credit="3" value="MAT165">Ordinary and Partial Differential Equati</option>
                                                <option credit="3" value="EEE411">Power Plant Engineering</option>
                                                <option credit="3" value="EEE303">Power System I</option>
                                                <option credit="3" value="EEE407">Power System II</option>
                                                <option credit="1" value="EEE408">Power System Lab</option>
                                                <option credit="3" value="EEE413">Power System Protection</option>
                                                <option credit="1" value="EEE414">Power System Protection Lab</option>
                                                <option credit="3" value="MAT263">Probability and Statistics</option>
                                                <option credit="3" value="EEE425">Processing and Fabrication Technology</option>
                                                <option credit="3" value="HUM483">Professional Ethics</option>
                                                <option credit="6" value="EEE490">Project</option>
                                                <option credit="3" value="CSE455">Real Time Computer System</option>
                                                <option credit="3" value="EEE305">Signals &amp; Systems</option>
                                                <option credit="3" value="CSE451">Software Engineering</option>
                                                <option credit="1" value="CSE452">Software Engineering Lab</option>
                                                <option credit="3" value="EEE307">Solid State Devices</option>
                                                <option credit="3" value="ECE433">Telecommunication Engineering</option>
                                                <option credit="1" value="ECE434">Telecommunication Engineering Lab</option>
                                                <option credit="3" value="GED101">The Four Skills of Communication in English I</option>
                                                <option credit="3" value="GED103">The Four Skills of Communication in English II</option>
                                                <option credit="2" value="EEE291">Thermodynamics, Refrigerator and Air Conditioning</option>
                                                <option credit="1" value="EEE292">Thermodynamics, Refrigerator and Air Conditioning Lab</option>
                                                <option credit="3" value="EEE423">VLSI</option>
                                                <option credit="1" value="EEE424">VLSI Lab</option>
                                                <option credit="3" value="PHY171">Waves, Optics &amp; Thermodynamics</option>
                                                <option credit="1" value="PHY172">Waves, Optics &amp; Thermodynamics Lab</option>
                                                <option credit="3" value="ECE429">Wireless &amp; Satellite Communication</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Semester</label>
                                        <div class="col-md-9">
                                            <select name="semester" class="form-control">
                                                <option value="">Select</option>
                                                <option value="Spring">Spring</option>
                                                <option value="Summer">Summer</option>
                                                <option value="Fall">Fall</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label">Year</label>
                                        <div class="col-md-9">
                                            <select name="year" class="form-control">
                                                <option value="">Select</option>
                                                <option value="2017"> 2017</option>
                                                <option value="2016"> 2016</option>
                                                <option value="2015"> 2015</option>
                                                <option value="2014"> 2014</option>
                                                <option value="2013"> 2013</option>
                                                <option value="2012"> 2012</option>
                                                <option value="2011"> 2011</option>
                                                <option value="2010"> 2010</option>
                                                <option value="2009"> 2009</option>
                                                <option value="2008"> 2008</option>
                                                <option value="2007"> 2007</option>
                                                <option value="2006"> 2006</option>
                                                <option value="2005"> 2005</option>
                                                <option value="2004"> 2004</option>
                                                <option value="2003"> 2003</option>
                                            </select>
                                        </div>
                                    </div>

                                    <button type="button" class="btn btn-primary center-block demo_student_update">Insert <span class="glyphicon glyphicon-floppy-saved" aria-hidden="true"></span></button>


                                </div>
                                <!-- end row -->
                            </fieldset>

                            <!-- #modal-alert -->
                            <div class="modal fade" id="modal-alert-update">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                            <h4 class="modal-title">Student Update</h4>
                                        </div>
                                        <div class="modal-body">
                                            <div class="alert alert-success m-b-0">
                                                <h4><i class="fa fa-info-circle"></i> Successfully Student Updated</h4>
                                                <p>Student successfully updated, You can update anytime.</p>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <a href="javascript:;" class="btn btn-sm btn-success" data-dismiss="modal">Done</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <!-- end: Demo Data Upload - current semester -->
        </div>
        <!-- end col-8 -->
        <!-- begin col-4 -->
        <div class="col-md-4">
            <div class="panel panel-inverse" data-sortable-id="index-10">
                <div class="panel-heading">
                    <div class="panel-heading-btn">
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-default" data-click="panel-expand"><i class="fa fa-expand"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-success" data-click="panel-reload"><i class="fa fa-repeat"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-warning" data-click="panel-collapse"><i class="fa fa-minus"></i></a>
                        <a href="javascript:;" class="btn btn-xs btn-icon btn-circle btn-danger" data-click="panel-remove"><i class="fa fa-times"></i></a>
                    </div>
                    <h4 class="panel-title">FPS Management</h4>
                </div>
                <div class="panel-body">
                    <button type="button" class="btn btn-success m-r-5 m-b-5">Delete All</button>
                    <p></p>
                    <div class="input-group">
                        <input type="text" class="form-control">
                        <div class="input-group-btn">
                            <button type="button" class="btn btn-success">Delete ID</button>
                        </div>
                    </div>
                    <p></p>
                    <div class="input-group">
                        <input type="text" class="form-control">
                        <div class="input-group-btn">
                            <button type="button" class="btn btn-success">View Student By ID</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- end col-4 -->
    </div>
    <!-- end row -->
</div>
<!-- end #content -->
<!-- start : staff registration -->
<script>
    $(document).ready(function() {

        /*
         * Start : Student Registration
         * */

        $(".form_registration").on('click','.next',function()
        {
            var _token                  = $("input[name=_token]").val();
            var name                    = $(".form_registration input[name=name]").val();
            var designation             = $(".form_registration select[name=designation]").val();
            var joining_date            = $(".form_registration input[name=joining_date]").val();
            var current_status          = $(".form_registration select[name=current_status]").val();
            var username                = $(".form_registration input[name=username]").val();
            var password                = $(".form_registration input[name=password]").val();
            var mobile_number           = $(".form_registration input[name=mobile_number]").val();
            var email                   = $(".form_registration input[name=email]").val();
            var current_address         = $(".form_registration input[name=current_address]").val();
            var permanent_address       = $(".form_registration input[name=permanent_address]").val();
            var status                  = $(".form_registration select[name=status]").val();

            var StaffInfo = {

                _token                  : _token,
                name                    : name,
                designation             : designation,
                joining_date            : joining_date,
                current_status          : current_status,
                username                : username,
                password                : password,
                mobile_number           : mobile_number,
                email                   : email,
                current_address         : current_address,
                permanent_address       : permanent_address,
                status                  : status
            };

            request.method   = "POST"       	              ;
            request.route    = 'admin/staffs/registration'     ;
            request.action   = ''          	                  ;
            request.data     = StaffInfo                      ;
            request.sync     = true		                      ;

            var response = ajaxapp.request(
                    'FPS_StatusGetCon = false;' +
                    'FPS_StatusSetClear = true;' +
                    '$(".ViewProfile").attr("href",HTTP_SERVER+"/admin/student/profile/"+return_data+"/view");' +
                    '$(".SuccessInfo").show();' +
                    '$("#modal-alert").modal("show");','');
            //setTimeout(function(){ FPS_StatusGetCon = true; FPS_Status() },1000);
        });
        /*
         * end : Student Registration
         *
         * Retrive period - 15 seconds
         * */

        /*
         * Start : Finger print status retrieve
         * */

        var ExecutionTime       = 50000   ; //50 seconds
        var TimeExpand          = 0       ;
        var ExecutionInterval   = 1000    ;
        var FPS_StatusGetCon    = false   ; // Get Continuously FPS Status - value - true = continuous get
        var FPS_StatusSetClear  = false   ;
        /*
        * SyncProcedure - Synchronization Procedure
        *
        * Single time retrieve or multitime retrieve
        * pass value value - boolean
        * */
        FPS_Running = false;

        function FPS_Status()
        {
            if(FPS_StatusGetCon == true)
            {
                if(FPS_Running == false) // if new FPS_Status create then TimeExpand set to 0
                {
                    FPS_StatusGet();

                    if(TimeExpand <= ExecutionTime)
                    {
                        TimeExpand += ExecutionInterval;
                        FPS_Running = true;

                        var t = setTimeout(function(){
                            FPS_Running = false;
                            FPS_Status();
                        } , ExecutionInterval);

                    }
                    else //set the default value
                    {
                        TimeExpand          = 0     ;
                        FPS_StatusGetCon    = false ;
                    }
                }
                else
                {
                    TimeExpand = 0 ;
                }
            }
            else //set the default value
            {
                TimeExpand          = 0     ;
                FPS_StatusGetCon    = false ;
            }
        }

        function FPS_StatusGet()
        {
            var _token = $("input[name=_token]").val();

            var info = {

                _token : _token
            };

            request.method   = "POST"       	            ;
            request.route    = 'admin/FPS_ScanningStatus'   ;
            request.action   = ''          	                ;
            request.data     = info                         ;
            request.sync     = true		                    ;

            ajaxapp.request('$(".FingerPrintStatus").html(return_data)');

            (FPS_StatusSetClear == true) ? FPS_StatusClear() : '' ;
            FPS_StatusSetClear = false ;
        }
        /*
         * end : Finger print status retrieve
         * */
        function FPS_StatusClear()
        {
            var _token = $("input[name=_token]").val();

            var info = {

                _token : _token
            };

            request.method   = "POST"       	            ;
            request.route    = 'admin/FPS_ScanningStatusClear'   ;
            request.action   = ''          	                ;
            request.data     = info                         ;
            request.sync     = false		                ;

            var response = ajaxapp.request();

            if(response != null)
            {
                $(".FingerPrintStatus").html(response);
            }
        }
        /*
         * end : Finger print status clear
         * */

        /*
         * Start : Student Search
         * */

        $(".form_demo_update").on('click','.demo_student_search_btn',function()
        {
            var _token              = $("input[name=_token]").val();
            var student_id          = $(".form_demo_update input[name=demo_student_id]").val();

            var StudentInfo = {

                _token              : _token ,
                student_id          : student_id
            };

            request.method   = "POST"       	        ;
            request.route    = 'admin/student/search'   ;
            request.action   = ''          	            ;
            request.data     = StudentInfo              ;
            request.sync     = false		            ;

            var response = ajaxapp.request();

            if(response)
            {
                if(!response.photo)
                {
                    var photo = 'public/200x200.svg';
                }
                else
                {
                    var  photo = response.photo;
                }
                response.photo = (response.photo)? response.photo : 'public/200x200.svg' ;
                $(".form_demo_update input[name=demo_student_id_disabled]").val(response.student_id);
                $(".form_demo_update input[name=demo_student_name]").val(response.name);
                $(".form_demo_update .demo_student_photo").attr('src', ajaxapp.baseUrl+'/local/storage/app/'+photo);
                $(".form_demo_update input[name=demo_fathers_name]").val(response.fathers_name);
                $(".form_demo_update input[name=demo_mothers_name]").val(response.mothers_name);
                $(".form_demo_update input[name=demo_date_of_birth]").val(response.date_of_birth);
                $(".form_demo_update select[name=demo_marital_status]").val(response.marital_status);
                $(".form_demo_update select[name=demo_gender]").val(response.gender);
                $(".form_demo_update textarea[name=demo_permanent_address]").val(response.permanent_address);
                $(".form_demo_update textarea[name=demo_presemt_address]").val(response.present_address);
                $(".form_demo_update select[name=demo_country]").val(response.country);
                $(".form_demo_update input[name=demo_cell_number]").val(response.cell_number);
                $(".form_demo_update input[name=demo_alternet_number]").val(response.alternet_number);
                $(".form_demo_update input[name=demo_email]").val(response.email);

                $(".form_demo_update .search").addClass('hide');
                $(".form_demo_update .student_info").removeClass('hide');
            }
        });

        /*
         * End : Student search
         * */

        /*
        * Start : Back Button
        * */
        $(".form_demo_update").on('click','.student_info .back',function()
        {
            $(".form_demo_update .search").removeClass('hide');
            $(".form_demo_update .student_info").addClass('hide');
        });
        /*
         * End : Back Button
         * */


        /*
         * Start : Student Update
         * */

        $(".form_demo_update").on('click','.demo_student_update',function()
        {
            var _token              = $("input[name=_token]").val();
            var student_id          = $(".form_demo_update input[name=demo_student_id]").val();
            var name                = $(".form_demo_update input[name=demo_student_name]").val();
            var fathers_name        = $(".form_demo_update input[name=demo_fathers_name]").val();
            var mothers_name        = $(".form_demo_update input[name=demo_mothers_name]").val();
            var date_of_birth       = $(".form_demo_update input[name=demo_date_of_birth]").val();
            var marital_status      = $(".form_demo_update select[name=demo_marital_status]").val();
            var gender              = $(".form_demo_update select[name=demo_gender]").val();
            var permanent_address   = $(".form_demo_update textarea[name=demo_permanent_address]").val();
            var presemt_address     = $(".form_demo_update textarea[name=demo_presemt_address]").val();
            var country             = $(".form_demo_update select[name=demo_country]").val();
            var cell_number         = $(".form_demo_update input[name=demo_cell_number]").val();
            var alternet_number     = $(".form_demo_update input[name=demo_alternet_number]").val();
            var email               = $(".form_demo_update input[name=demo_email]").val();

            var StudentInfo = {

                _token              : _token ,
                student_id          : student_id ,
                name                : name ,
                fathers_name        : fathers_name ,
                mothers_name        : mothers_name ,
                date_of_birth       : date_of_birth ,
                marital_status      : marital_status ,
                gender              : gender ,
                permanent_address   : permanent_address ,
                presemt_address     : presemt_address ,
                country             : country ,
                cell_number         : cell_number ,
                alternet_number     : alternet_number ,
                email               : email
            };

            request.method   = "POST"       	        ;
            request.route    = 'admin/student/update'   ;
            request.action   = ''          	            ;
            request.data     = StudentInfo              ;
            request.sync     = true		                ;

            var response = ajaxapp.request('$("#modal-alert-update").modal("show");','');
        });

        /*
        * End : Student Update
        * */





        /*
         * Start : Student Search for academic info
         * */
        function AcademicSearch()
        {
            var e = '.form_demo_update_academic';

            var _token              = $("input[name=_token]").val();
            var student_id          = $(e+" input[name=demo_student_id]").val();

            var StudentInfo = {

                _token              : _token ,
                student_id          : student_id
            };

            request.method   = "POST"       	        ;
            request.route    = 'admin/student/search'   ;
            request.action   = ''          	            ;
            request.data     = StudentInfo              ;
            request.sync     = false		            ;

            var response = ajaxapp.request();

            if(response)
            {
                $(e+" table tbody").empty();

                if(response['academic']) {
                    var i = 0;
                    for (i = 0; i < response['academic'].length; i++) {

                        var student_id = response['academic'][i]['student_id'];
                        var course_name = response['academic'][i]['course_name'];
                        var course_code = response['academic'][i]['course_code'];
                        var course_credit = response['academic'][i]['course_credit'];
                        var semester = response['academic'][i]['semester'];
                        var year = response['academic'][i]['year'];
                        var letter_grade = response['academic'][i]['letter_grade'];
                        var grade_point = response['academic'][i]['grade_point'];

                        var html = '';

                        html += '<tr>';
                        html += '<td>' + i + '</td>';
                        html += '<td>' + course_code + '</td>';
                        html += '<td>' + course_name + '</td>';
                        html += '<td>' + course_credit + '</td>';
                        html += '<td>' + letter_grade + '</td>';
                        html += '<td>' + course_credit + '</td>';
                        html += '<td>' + grade_point + '</td>';
                        html += '<td>' + semester + ' ' + year + '</td>';
                        html += '</tr>';

                        $(e + " table tbody").append(html);
                    }
                }

                $(e+" input[name=demo_student_id_disabled]").val(response.student_id);

                $(e+" .search").addClass('hide');
                $(e+" .student_info").removeClass('hide');
            }
        }

        $(".form_demo_update_academic").on('click','.demo_student_search_btn',function()
        {
            AcademicSearch();
        });

        /*
         * End : Student search for academic info
         * */

        /*
         * Start : Back Button
         * */
        $(".form_demo_update_academic").on('click','.student_info .back',function()
        {
            $(".form_demo_update_academic .search").removeClass('hide');
            $(".form_demo_update_academic .student_info").addClass('hide');
        });
        /*
         * End : Back Button
         * */


        /*
         * Start : Student Academic Info insert
         * */

        $(".form_demo_update_academic").on('click','.demo_student_update',function()
        {
            var e = '.form_demo_update_academic' ;

            var _token              = $("input[name=_token]").val();

            var student_id      = $(e+" input[name=demo_student_id]").val();
            var course_code     = $(e+" select[name=demo_course]").val();
            var course_name     = $(e+" select[name=demo_course] option[value="+course_code+"]").text();
            var course_credit   = $(e+" select[name=demo_course] option[value="+course_code+"]").attr('credit');
            var semester        = $(e+" select[name=semester]").val();
            var year            = $(e+" select[name=year]").val();
            var grade_point     = $(e+" input[name=demo_grade_point]").val();

            var info = {

                _token          : _token,
                student_id      : student_id,
                course_name     : course_name,
                course_code     : course_code,
                course_credit   : course_credit,
                semester        : semester,
                year            : year,
                grade_point     : grade_point
            };

            request.method   = "POST"       	                ;
            request.route    = 'admin/student/academic/insert'  ;
            request.action   = ''          	                    ;
            request.data     = info                             ;
            request.sync     = false		                    ;

            var response = ajaxapp.request('$("#modal-alert-update").modal("show");','');
            AcademicSearch();
        });

        /*
         * End : Student Academic Info insert
         * */


        /*
        * start: student photo upload
        * */
        $(".student_info").on("change","input[type=file]",function(){
            var this_el=$(this);

            var _token      = $("input[name=_token]").val();
            var student_id  = $(".form_demo_update input[name=demo_student_id]").val();


            var file = this.files[0];
            name = file.name;
            size = file.size;
            type = file.type;

            if(file.name.length < 1) {}
            else if(file.size > 150000) {alert("The system will not take more then 150KB image size - 200x200px.");}//50000 = 50KB
            else if(file.type != 'image/png' && file.type != 'image/jpg' && !file.type != 'image/gif' && file.type != 'image/jpeg' ) {alert("This file is not image file.\n Please upload optimized jpg or png");}
            else {

                var formdata = false;
                if (window.FormData) {formdata = new FormData();}

                formdata.append("imgfile", file);
                formdata.append("_token", _token);
                formdata.append("student_id", student_id);

                jQuery.ajax({

                    url: "admin/student/update/photo",
                    type: "POST",
                    data: formdata,
                    processData: false,
                    contentType: false,
                    success: function (data) {
                        var res = JSON.parse(data);

                        var x,i=1;
                        for(x in res['Message'].text)
                        {
                            ajaxapp.notify.text(res['Message'].text[x]);
                        }

                        if(res['SuccessStatus']==1)
                        {
                            return_data = res['ResponseData'] ;
                            $(".form_demo_update .demo_student_photo").attr('src', return_data);

                        }
                    }
                });
            }

        });
        /*
         * end: student photo upload
         * */






        /*
         * Start : Student Search for current semester
         * */
        function CurrentSemesterSearch()
        {
            var e = '.form_demo_update_current_semester';

            var _token              = $("input[name=_token]").val();
            var student_id          = $(e+" input[name=demo_student_id]").val();

            var StudentInfo = {

                _token              : _token ,
                student_id          : student_id
            };

            request.method   = "POST"       	        ;
            request.route    = 'admin/student/search'   ;
            request.action   = ''          	            ;
            request.data     = StudentInfo              ;
            request.sync     = false		            ;

            var response = ajaxapp.request();

            if(response)
            {
                $(e+" table tbody").empty();

                if(response['current_semester'])
                {
                    var i = 0;
                    for (i = 0; i < response['current_semester'].length; i++) {

                        var student_id = response['current_semester'][i]['student_id'];
                        var course_name = response['current_semester'][i]['course_name'];
                        var course_code = response['current_semester'][i]['course_code'];
                        var course_credit = response['current_semester'][i]['course_credit'];
                        var semester = response['current_semester'][i]['semester'];
                        var year = response['current_semester'][i]['year'];

                        var html = '';

                        html += '<tr>';
                        html += '<td>' + i + '</td>';
                        html += '<td>' + course_code + '</td>';
                        html += '<td>' + course_name + '</td>';
                        html += '<td>' + course_credit + '</td>';
                        html += '<td>' + semester + ' ' + year + '</td>';
                        html += '</tr>';

                        $(e + " table tbody").append(html);
                    }
                }

                $(e+" input[name=demo_student_id_disabled]").val(response.student_id);

                $(e+" .search").addClass('hide');
                $(e+" .student_info").removeClass('hide');
            }
        }

        $(".form_demo_update_current_semester").on('click','.demo_student_search_btn',function()
        {
            CurrentSemesterSearch();
        });

        /*
         * End : Student search for current semester
         * */

        /*
         * Start : Back Button current semester
         * */
        $(".form_demo_update_current_semester").on('click','.student_info .back',function()
        {
            $(".form_demo_update_current_semester .search").removeClass('hide');
            $(".form_demo_update_current_semester .student_info").addClass('hide');
        });
        /*
         * End : Back Button current semester
         * */


        /*
         * Start : Student current semester insert
         * */

        $(".form_demo_update_current_semester").on('click','.demo_student_update',function()
        {
            var e = '.form_demo_update_current_semester' ;

            var _token              = $("input[name=_token]").val();

            var student_id      = $(e+" input[name=demo_student_id]").val();
            var course_code     = $(e+" select[name=demo_course]").val();
            var course_name     = $(e+" select[name=demo_course] option[value="+course_code+"]").text();
            var course_credit   = $(e+" select[name=demo_course] option[value="+course_code+"]").attr('credit');
            var semester        = $(e+" select[name=semester]").val();
            var year            = $(e+" select[name=year]").val();

            var info = {

                _token          : _token,
                student_id      : student_id,
                course_name     : course_name,
                course_code     : course_code,
                course_credit   : course_credit,
                semester        : semester,
                year            : year
            };

            request.method   = "POST"       	                        ;
            request.route    = 'admin/student/current_semester/insert'  ;
            request.action   = ''          	                            ;
            request.data     = info                                     ;
            request.sync     = false		                            ;

            var response = ajaxapp.request('$("#modal-alert-update").modal("show");','');
            CurrentSemesterSearch();
        });

        /*
         * End : Student current semester insert
         * */
    });
</script>
<!-- end : staff registration -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>