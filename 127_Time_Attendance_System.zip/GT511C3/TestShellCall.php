<?php
/**
 * Created by PhpStorm.
 * User: Mizan
 * Date: 6/30/2017
 * Time: 12:09 PM
 */
echo shell_exec('print testv');