import os
print(os.path.abspath(__file__))