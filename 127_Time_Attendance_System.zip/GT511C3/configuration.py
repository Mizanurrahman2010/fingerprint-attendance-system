import FPS, sys

DEVICE_GPIO = '/dev/ttyAMA0'
DEVICE_LINUX = '/dev/ttyUSB0'
DEVICE_MAC = '/dev/cu.usbserial-A601EQ14'
DEVICE_WINDOWS = 'COM6'
FPS.BAUD = 9600
FPS.DEVICE_NAME = DEVICE_LINUX

# FPS_Directory = '/var/www/html/GT511C3/'
FPS_Directory = 'D:/xampp/htdocs/127_Time_Attendance_System/GT511C3/'